//
//  main.swift
//  TestClosuresSwift
//
//  Created by Robert Seitsinger on 2/29/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import Foundation

// Define a function that includes an argument which is a completion block.
func doSomeStuff(input: String, completion: (result: String) -> Void) {
    print("Doing some stuff in doSomeStuff")
    // Call the completion block.
    completion(result: "we finished!")
}

func main() {
    // Call doSomeStuff and pass in a completion block.
    doSomeStuff("commands") {
        (result: String) in
        print("got back: \(result)")
    }
}

main()
