//
//  AppDelegate.swift
//  TestLocalNotifications1Swift
//
//  Created by Robert Seitsinger on 3/9/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.

        print("didFinishLaunchingWithOptions: Entry.")
        
        // You MUST register the intent to receive notifications, or you won't get them.
        // This also causes the prompt to the user (once) asking to allow the app to receive notifications.
        let settings = UIUserNotificationSettings(forTypes: [.Alert], categories: nil)
        UIApplication.sharedApplication().registerUserNotificationSettings(settings)
        
        return true
    }

    // This gets called when the operating system has a notification to give you.
    // The operating system makes sure the app is both running and in the foreground before calling this method.
    func application(application: UIApplication, didReceiveLocalNotification notification: UILocalNotification) {
        
        // Get the data that was passed in the notification.
        let notifyType = notification.userInfo!["notifyType"]!
        let aNumber = notification.userInfo!["someNumber"]!
        
        print("didReceiveLocalNotification: Entry. Notification Type: ", notifyType, ", Number: ", aNumber)
        
        // Reset the app icon badge count
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

