//
//  ViewController.swift
//  TestLocalNotifications1Swift
//
//  Created by Robert Seitsinger on 3/9/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnScheduleNotificationAction(sender: AnyObject) {
        
        let aVar = 350
        
        let notification = UILocalNotification()
        
        // Define what gets displayed in the drop-down, if app in background or not running.
        notification.alertBody = "Hey! Look at this!"
        // Define when to fire this notification - now + 6 seconds.
        notification.fireDate = NSDate(timeIntervalSinceNow: 6)
        // Include 2 pieces of data in the notification.
        notification.userInfo = ["notifyType" : "notify1", "someNumber" : 500, "anotherNumber" : aVar]
        // Increment the app icon badge count - to indicate to the user they received some notifications.
        notification.applicationIconBadgeNumber = UIApplication.sharedApplication().applicationIconBadgeNumber + 1;

        // Schedule the notification with the operating system.
        // The operating system makes sure the app is both running and in the foreground,
        // then calls didReceiveLocalNotification, passing in your notification.
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
    }
}

