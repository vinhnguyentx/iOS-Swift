//
//  ViewController.swift
//  TestMotionShake1Swift
//
//  Created by Robert Seitsinger on 11/10/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    
    var previousShakenState = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lbl.text = "Shake Me"
        self.lbl.backgroundColor = UIColor.lightGrayColor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Indicate we want this view controller to respond to events.
    override func canBecomeFirstResponder() -> Bool {
        return true
    }
    
    override func motionEnded(motion: UIEventSubtype, withEvent event: UIEvent?) {
        // Handle motion events.
        if motion == .MotionShake {
            if self.previousShakenState {
                self.previousShakenState = false
                self.lbl.text = "Shake Me"
                self.lbl.backgroundColor = UIColor.lightGrayColor()
            } else {
                self.previousShakenState = true
                self.lbl.text = "HEY!  Stop That!!!"
                self.lbl.backgroundColor = UIColor.redColor()
            }
        }
    }
}

