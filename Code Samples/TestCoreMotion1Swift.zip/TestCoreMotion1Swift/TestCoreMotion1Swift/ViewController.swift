//
//  ViewController.swift
//  TestCoreMotion1Swift
//
//  Created by Robert Seitsinger on 11/8/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    // Create a shared CMMotionManager object - provides access to all sensor APIs.
    let motionManager = CMMotionManager()
    
    var currentMaxAccelX:Double = 0
    var currentMaxAccelY:Double = 0
    var currentMaxAccelZ:Double = 0
    var currentMaxRotX:Double = 0
    var currentMaxRotY:Double = 0
    var currentMaxRotZ:Double = 0
    
    @IBOutlet weak var lblAccX: UILabel!
    @IBOutlet weak var lblAccY: UILabel!
    @IBOutlet weak var lblAccZ: UILabel!
    
    @IBOutlet weak var lblRotX: UILabel!
    @IBOutlet weak var lblRotY: UILabel!
    @IBOutlet weak var lblRotZ: UILabel!
    
    @IBOutlet weak var lblMaxAccX: UILabel!
    @IBOutlet weak var lblMaxAccY: UILabel!
    @IBOutlet weak var lblMaxAccZ: UILabel!
    
    @IBOutlet weak var lblMaxRotX: UILabel!
    @IBOutlet weak var lblMaxRotY: UILabel!
    @IBOutlet weak var lblMaxRotZ: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.currentMaxAccelX = 0
        self.currentMaxAccelY = 0
        self.currentMaxAccelZ = 0
        self.currentMaxRotX = 0
        self.currentMaxRotY = 0
        self.currentMaxRotZ = 0
        
        // Define how frequently we want to receive updates. The updates are received in the code blocks below.
        self.motionManager.accelerometerUpdateInterval = 0.2;
        self.motionManager.gyroUpdateInterval = 0.2;
        self.motionManager.deviceMotionUpdateInterval = 0.2
        
        // Setup 'push' of motion data changes.
        
        // '#if true' - enables usage of the accelerometer and gyro objects.
        // '#if false' - enables usage of the device motion object.
        
#if false // use accelerometer and gyro objects
        self.motionManager.startAccelerometerUpdatesToQueue(NSOperationQueue.currentQueue()!, withHandler: {
            (accelerometerData:CMAccelerometerData?, error:NSError?) in
            
                self.outputAccelertionData(accelerometerData!.acceleration)
                if error != nil {
                    print("\(error!)")
                }
        })

        self.motionManager.startGyroUpdatesToQueue(NSOperationQueue.currentQueue()!, withHandler: {
            (gyroData:CMGyroData?, error:NSError?) in
            
                self.outputRotationData(gyroData!.rotationRate)
                if error != nil {
                    print("\(error!)")
                }
        })
#else
        self.motionManager.startDeviceMotionUpdatesToQueue(NSOperationQueue.currentQueue()!, withHandler: {
            (deviceMotion:CMDeviceMotion?, error:NSError? ) in
            
            self.outputDeviceMotionData(deviceMotion!)
            if error != nil {
                print("\(error!)")
            }
        })
#endif
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func shouldAutorotate() -> Bool {
        return false
    }
    
    // Lock to portrait orientation
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return [UIInterfaceOrientationMask.Portrait]
    }
    
    @IBAction func btnResetAction(sender: AnyObject) {
        currentMaxAccelX = 0
        currentMaxAccelY = 0
        currentMaxAccelZ = 0
        
        currentMaxRotX = 0
        currentMaxRotY = 0
        currentMaxRotZ = 0
    }

    func outputAccelertionData(acceleration:CMAcceleration) {
        self.lblAccX.text = String(format: " %.2fg", acceleration.x)
        if fabs(acceleration.x) > fabs(currentMaxAccelX) {
            currentMaxAccelX = acceleration.x;
        }
        self.lblAccY.text = String(format: " %.2fg", acceleration.y)
        if fabs(acceleration.y) > fabs(currentMaxAccelY) {
            currentMaxAccelY = acceleration.y;
        }
        self.lblAccZ.text = String(format: " %.2fg", acceleration.z)
        if fabs(acceleration.z) > fabs(currentMaxAccelZ) {
            currentMaxAccelZ = acceleration.z;
        }
        
        self.lblMaxAccX.text = String(format: " %.2f", currentMaxAccelX)
        self.lblMaxAccY.text = String(format: " %.2f", currentMaxAccelY)
        self.lblMaxAccZ.text = String(format: " %.2f", currentMaxAccelZ)
    }
    
    func outputRotationData(rotation:CMRotationRate) {
        self.lblRotX.text = String(format: " %.2fr/s", rotation.x)
        if(fabs(rotation.x) > fabs(currentMaxRotX)) {
            currentMaxRotX = rotation.x;
        }
        self.lblRotY.text = String(format: " %.2fr/s", rotation.y)
        if(fabs(rotation.y) > fabs(currentMaxRotY)) {
            currentMaxRotY = rotation.y;
        }
        self.lblRotZ.text = String(format: " %.2fr/s", rotation.z)
        if(fabs(rotation.z) > fabs(currentMaxRotZ)) {
            currentMaxRotZ = rotation.z;
        }
        
        self.lblMaxRotX.text = String(format: " %.2f", currentMaxRotX)
        self.lblMaxRotY.text = String(format: " %.2f", currentMaxRotY)
        self.lblMaxRotZ.text = String(format: " %.2f", currentMaxRotZ)
    }

    func outputDeviceMotionData(deviceMotion:CMDeviceMotion) {
        
        self.outputAccelertionData(deviceMotion.userAcceleration)
        self.outputRotationData(deviceMotion.rotationRate)
    }
    
}

