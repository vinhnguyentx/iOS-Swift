//
//  BeerCell.swift
//  BeerButton
//
//  Created by Conrad Stoll on 11/1/15.
//  Copyright © 2015 Conrad Stoll. All rights reserved.
//

import Foundation
import UIKit

class BeerCell : UITableViewCell {
    @IBOutlet weak var beerLabel : UILabel?
    @IBOutlet weak var beerImage : UIImageView?
}
