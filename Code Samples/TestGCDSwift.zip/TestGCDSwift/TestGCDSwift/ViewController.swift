//
//  ViewController.swift
//  TestGCDSwift
//
//  Created by Robert Seitsinger on 9/24/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

// Output:
// viewDidLoad: Entry
// Thread 1: waiting
// Thread 1: waiting - done
// Thread 2: waiting
// Thread 2: waiting - done
// viewDidLoad: Exit
// Thread 3: waiting
// Thread 4: waiting
// Thread 5: dispatch_after
// Thread 5: dispatch_after - done
// GUI thread 4
// GUI thread 3

class ViewController: UIViewController {

    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("viewDidLoad: Entry");
        
        // Now that the UI has been loaded, we can fire off our code chunks
        
        dispatch_sync(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            print("Thread 1: waiting");
            // wait
            sleep(2)
            print("Thread 1: waiting - done");
        }
        
        dispatch_sync(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            print("Thread 2: waiting");
            // wait
            sleep(2)
            print("Thread 2: waiting - done");
        }
        
        dispatch_async(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            print("Thread 3: waiting");
            // wait
            sleep(5)
            // queue the task to the main queue, since it's doing UI stuff
            dispatch_async(dispatch_get_main_queue()) {
                // GUI thread
                print("GUI thread 3");
                // update label 1 text
                self.label1.text = "Done with Label 1";
            }
        }

        dispatch_async(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            print("Thread 4: waiting");
            // wait
            sleep(2)
            // queue the task to the main queue, since it's doing UI stuff
            dispatch_async(dispatch_get_main_queue()) {
                // GUI thread
                print("GUI thread 4");
                // update label 2 text
                self.label2.text = "Done with Label 2";
            }
        }

        // Delay starting work with dispatch_after
        let delayInSeconds = 1.5
        let popTime = dispatch_time(DISPATCH_TIME_NOW, Int64(delayInSeconds * Double(NSEC_PER_SEC)))
        dispatch_after(popTime, dispatch_get_main_queue()) {
            print("Thread 5: dispatch_after");
            // wait
            sleep(3)
            print("Thread 5: dispatch_after - done");
        }
        
        print("viewDidLoad: Exit");
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

