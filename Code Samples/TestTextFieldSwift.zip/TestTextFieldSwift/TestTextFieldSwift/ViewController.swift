//
//  ViewController.swift
//  TestTextFieldSwift
//
//  Created by Robert Seitsinger on 2/7/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtField1: UITextField!
    @IBOutlet weak var txtField2: UITextField!
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // You have to identify this object (self) as the one that will receive delegate calls
        // (think old-fashioned callbacks) from the framework code that handles UITextField
        // events. If you don't, the framework's call to textFieldShouldReturn (below) won't
        // get here, and the keyboard won't go away using this mechanism.
        self.txtField1.delegate = self
        self.txtField2.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func btnAction(sender: AnyObject) {
    }
    
    // UITextFieldDelegate delegate method
    //
    // This method is called when the user touches the Return key on the
    // keyboard. The 'textField' passed in is a pointer to the textField
    // widget the cursor was in at the time they touched the Return key on
    // the keyboard.
    //
    // From the Apple documentation: Asks the delegate if the text field
    // should process the pressing of the return button.
    //
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        // To do something specific for a given UITextField, when you have more
        // than one text field in a screen.
        if textField == self.txtField1 {
            print("You were in the first text field")
        }
        if textField == self.txtField2 {
            print("You were in the second text field")
        }
        
        // A responder is an object that can respond to events and handle them.
        //
        // Resigning first responder here means this text field will no longer be the first
        // UI element to receive an event from this apps UI - you can think of it as giving
        // up 'input focus'.
        textField.resignFirstResponder()
        
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    // This causes the keyboard to go away also - but handles all situations when
    // the user touches anywhere outside the keyboard.
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
}

