//
//  ViewController.swift
//  TestToolbar1Swift
//
//  Created by Robert Seitsinger on 4/4/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // The positioning of the 6 toolbar items is all done in Interface Builder.
        // Using a combination of constraints and fixed and flexible space bar button items.
        
        // Rotate orientation between portrait and landscape to better see the positioning.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btn1Action(sender: AnyObject) {
        print("You touched button 1")
    }
    
    @IBAction func btn2Action(sender: AnyObject) {
        print("You touched button 2")
    }
    
    @IBAction func btn3Action(sender: AnyObject) {
        print("You touched button 3")
    }
    
    @IBAction func btn4Action(sender: AnyObject) {
        print("You touched button 4")
    }
    
    @IBAction func btn5Action(sender: AnyObject) {
        print("You touched button 5")
    }
    
    @IBAction func btn6Action(sender: AnyObject) {
        print("You touched button 6")
    }
}

