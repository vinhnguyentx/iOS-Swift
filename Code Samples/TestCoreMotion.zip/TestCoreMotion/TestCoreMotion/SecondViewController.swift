//
//  SecondViewController.swift
//  TestCoreMotion
//
//  Created by Robert Seitsinger on 11/10/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

// This class doesn't do anything specific. This view controller is dismissed in the main view
// controller's device motion handler code, by tipping the phone towards you (the pitch).

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
