//
//  ViewController.swift
//  TestCoreMotion
//
//  Created by Robert Seitsinger on 11/10/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    let motionManager = CMMotionManager()
    var secondVC:SecondViewController? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Override the default update interval. If nothing else, the hardware's sensitivty to gravity
        // causes a continuous flow of new values. This throttles the flow of updates at least a little.
        self.motionManager.deviceMotionUpdateInterval = 0.05
        
        // The 'withHandler' code block has 2 arguments - deviceMotion, error.
        // The deviceMotion object contains the data we're interested in.
        self.motionManager.startDeviceMotionUpdatesToQueue( NSOperationQueue.currentQueue()!, withHandler: {
                (deviceMotion:CMDeviceMotion?, error:NSError? ) in
            
                // This code block gets executed for each update of the sensor data.
            
                print("\(deviceMotion!.attitude.pitch)  \(deviceMotion!.attitude.yaw)")
                
                // Dismiss the second view controller once the pitch becomes sufficiently positive.
                // A positive pitch indicates you are tipping the phone towards you. Turns out a pitch of about
                // 1.4 is almost vertical - portrait mode, straight up.
                if self.secondVC != nil {
                    if deviceMotion!.attitude.yaw < -1.55 || deviceMotion!.attitude.pitch > 1.4 {
                        print("**********************************")
                        print("*** DISMISSING VIEW CONTROLLER ***")
                        print("**********************************")
                        self.secondVC?.dismissViewControllerAnimated(true, completion: {})
                        self.secondVC = nil
                    }
                }
        })
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func shouldAutorotate() -> Bool {
        return false
    }
    
    // Lock to portrait orientation
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return [UIInterfaceOrientationMask.Portrait]
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

        if segue.identifier == "ShowSecondVC" {
            // Capture the pointer to the second view controller. We need this to dismiss that view
            // controller in the device motion handling code above.
            self.secondVC = segue.destinationViewController as? SecondViewController
        }
    }

}

