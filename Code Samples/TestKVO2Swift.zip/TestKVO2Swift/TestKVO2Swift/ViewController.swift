//
//  ViewController.swift
//  TestKVO2Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

// define a global context variable for the KVO
private var myContext = 0

class ViewController: UIViewController {
    
    // a constant for the observed property key path
    let observedPropertyKeyPath = "myObservedProperty"
    
    // define a property for the object that contains the property we want to observe
    var objectToObserve = MyObservedClass()

    @IBOutlet weak var txtField: UITextField!
    @IBOutlet weak var lblMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        // add the observer. the key path is the property in the class we want to observe.
        // we're asking to get sent both the old and new values.
        objectToObserve.addObserver(self, forKeyPath: observedPropertyKeyPath, options: [.Old, .New], context: &myContext)

        // initialize the text field to the observed property's initial value
        txtField.text = objectToObserve.myObservedProperty
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // This is the method that gets called when the observed property changes.
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        // Handle observations only for your context. Pass any others up the chain.
        if context == &myContext {
            let oldValue = change?[NSKeyValueChangeOldKey]
            let newValue = change?[NSKeyValueChangeNewKey]
            // update the label indicating something's changed with the observed property
            lblMessage.text = "Observed property changed from: \(oldValue!) to: \(newValue!)"
        } else {
            // Pass this up the chain.
            super.observeValueForKeyPath(keyPath, ofObject: object, change: change, context: context)
        }
    }
    
    deinit {
        // you need to remove the observer before this object goes away
        objectToObserve.removeObserver(self, forKeyPath: observedPropertyKeyPath, context: &myContext)
    }

    @IBAction func btnChangeAction(sender: AnyObject) {
        // update the observed value - to see the observer get triggered
        objectToObserve.updateProperty(txtField.text!)
    }
}

