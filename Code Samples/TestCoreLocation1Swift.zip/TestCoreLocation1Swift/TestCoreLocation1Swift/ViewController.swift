//
//  ViewController.swift
//  TestCoreLocation1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var lblUpdateLocationsCount: UILabel!
    @IBOutlet weak var lblUpdateHeadingsCount: UILabel!
    @IBOutlet weak var lblDidVisitCount: UILabel!
    @IBOutlet weak var lblHeadingDescription: UILabel!
    
    let locationManager = CLLocationManager()
    var alertController:UIAlertController? = nil
    var didUpdateHeadingCount = 0
    var didUpdateLocationCount = 0
    var didVisitCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Core Location Test"

        // Make sure the location service is available before trying to use it.
        if CLLocationManager.locationServicesEnabled() {
            // Configure the location manager for what we want to track.
            locationManager.desiredAccuracy = 100 // meters
            locationManager.delegate = self
            
            // If we haven't done so yet, we need to ask for access to the location data.
            if CLLocationManager.authorizationStatus() == .NotDetermined {
                // Must choose between requesting to get access to location data
                // either always or only when the app is running.
//                locationManager.requestWhenInUseAuthorization()
                locationManager.requestAlwaysAuthorization()
            }
        } else {
            self.displayAlert("Error", message: "Location Services not available!")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // This method gets called each time the app runs. First time, after the user
    // answers the prompt; all other times automatically - assuming the user said
    // yes to location access.
    func locationManager(manager: CLLocationManager,
                    didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        if status == .AuthorizedAlways || status == .AuthorizedWhenInUse {
            if status == .AuthorizedAlways {
                print("Authorized for Always")
            } else {
                print("Authorized for When In use")
            }
            // Start monitoring for various kinds of events here.
            // Callbacks will start occurring.
            manager.startUpdatingLocation()
            manager.startUpdatingHeading()
            manager.startMonitoringVisits()
        } else {
            print("Not Authorized")
        }
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // Make use of the CLLocation objects as desired.
        
        self.didUpdateLocationCount += 1
        self.updateUI()
//        self.printCounts()
//        self.displayCounts()
    }
    
    func locationManager(manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        // Make use of the CLHeading object as desired.
//        print("didUpdateHeading: " + newHeading.description)
        self.lblHeadingDescription.text = newHeading.description
        
        self.didUpdateHeadingCount += 1
        self.updateUI()
//        self.printCounts()
//        self.displayCounts()
    }

    func locationManager(manager: CLLocationManager, didVisit visit: CLVisit) {
        // Make use of the CLVisit object as desired.
        
        self.didVisitCount += 1
        self.updateUI()
//        self.printCounts()
//        self.displayCounts()
    }

    func getCountString() -> String {
        return "updateLocations: " + String(self.didUpdateLocationCount) +
            ", updateHeadings: " + String(self.didUpdateHeadingCount) +
            ", visit: " + String(self.didVisitCount)
    }
    
    func updateUI() {
        self.lblUpdateLocationsCount.text = String(self.didUpdateLocationCount)
        self.lblUpdateHeadingsCount.text = String(self.didUpdateHeadingCount)
        self.lblDidVisitCount.text = String(self.didVisitCount)
    }

    func printCounts() {
        print(self.getCountString())
    }
    
    func displayCounts() {
        self.displayAlert("Call Counts", message: self.getCountString())
    }
    
    func displayAlert(title:String, message:String) {
        self.alertController = UIAlertController(title:title, message:message, preferredStyle: UIAlertControllerStyle.Alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action:UIAlertAction) in
        }
        self.alertController!.addAction(okAction)
        self.presentViewController(self.alertController!, animated: true, completion:nil)
    }
}

