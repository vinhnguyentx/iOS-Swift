//
//  AppDelegate.swift
//  TesttvOS1Swift
//
//  Created by Robert Seitsinger on 4/20/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit
import TVMLKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, TVApplicationControllerDelegate {

    var window: UIWindow?
    
    var appController: TVApplicationController?  // Handles communicating with your server.
    static let TVBaseURL = "http://localhost:9001/"  // Path for your server. (9001 is the port).
    static let TVBootURL = "\(AppDelegate.TVBaseURL)js/application.js"  // Path for your JavaScript code.
    
    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        
        // Create a context, with is used to initialize the TVApplicationController.
        let appControllerContext = TVApplicationControllerContext()

        // Modify the context with:
        // 1. The root directory of your server.
        // 2. The path to your main Javascript file.
        appControllerContext.launchOptions["BASEURL"] = AppDelegate.TVBaseURL
        
        guard let javaScriptURL = NSURL(string: AppDelegate.TVBootURL) else {
            fatalError("unable to create NSURL")
        }
        appControllerContext.javaScriptApplicationURL = javaScriptURL
        
        // Start up the TVApplicationController with the context you configured.
        // At this point, Apple’s code takes over – it will pull down your root Javascript file and begin executing it.
        appController = TVApplicationController(context: appControllerContext, window: window, delegate: self)
        return true
    }
}
