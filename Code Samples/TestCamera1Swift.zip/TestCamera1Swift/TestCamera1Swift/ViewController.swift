//
//  ViewController.swift
//  TestCamera1Swift
//
//  Created by Robert Seitsinger on 11/11/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import MobileCoreServices // For the KUT types

// Need to include both the UIImagePickerControllerDelegate and UINavigationControllerDelegate
// protocols here, to satisfy the definition of the image picker delegate property.
class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    var newMedia: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // This method does the following:
    // 1. Check the device we're running on has a camera and the app can get access to it.
    // 2. Create a UIImagePickerController instance.
    // 3. Assign the delegate.
    // 4. Define the media source as the camera.
    // 5. Identify that we want to work with images; not videos.
    // 6. Do not allow editing.
    // 7. Show the camera controls.
    // 8. Present the camera UI.
    // 9. Set the newMedia flag to true, to indicate that the image is new and is not an existing
    //    image from the camera roll/photo library.
    //
    @IBAction func btnCameraAction(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) {
                
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.Camera
            imagePicker.mediaTypes = [kUTTypeImage as NSString as String]
            imagePicker.allowsEditing = false
            imagePicker.showsCameraControls = true
            
            self.presentViewController(imagePicker, animated: true, completion: nil)
        
            newMedia = true
        }
    }

    // This method does the following:
    // 1. Check the app has access to the camera roll.
    // 2. Create a UIImagePickerController instance.
    // 3. Assign the delegate.
    // 4. Define the media source as the camera roll.
    // 5. Present the photo picker UI.
    // 6. Set the newMedia flag to false, to indicate the image is an existing image from the camera roll.
    //
    @IBAction func btnCameraRollAction(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum) {
            
                let imagePicker = UIImagePickerController()
                
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum
                imagePicker.mediaTypes = [kUTTypeImage as NSString as String]
                imagePicker.allowsEditing = false
            
                self.presentViewController(imagePicker, animated: true, completion: nil)
            
                newMedia = false
        }
    }

    // This method does the following:
    // 1. Check the app has access to the photo library.
    // 2. Create a UIImagePickerController instance.
    // 3. Assign the delegate.
    // 4. Define the media source as the photo library.
    // 5. Present the photo picker UI.
    // 6. Set the newMedia flag to false, to indicate the image is an existing image from the photo library.
    //
    @IBAction func btnPhotoLibraryAction(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
            imagePicker.mediaTypes = [kUTTypeImage as NSString as String]
            imagePicker.allowsEditing = false
            
            self.presentViewController(imagePicker, animated: true, completion: nil)
            
            newMedia = false
        }
    }
    
    // MARK: UIImagePickerControllerDelegate methods
    
    // Called when an image is available from any of the 3 contexts - camera, camera roll or photo library.
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! String
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
        if mediaType == kUTTypeImage as String {
            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
            
            // Update the image view with the new picture from the camera, or selected image
            // from the camera roll or photo library.
            self.imageView.image = image
            
            // If we created a new image with the camera, save it.
            if (newMedia == true) {
                // The third argument is the 'completion method selector' - a function that is called when the save
                // operation is done. The method name has an objective-c signature.
                UIImageWriteToSavedPhotosAlbum(image, self, #selector(ViewController.image(_:didFinishSavingWithError:contextInfo:)), nil)
            }
        }
    }
    
    // Called when an image is saved - successfully or not.
    func image(image: UIImage, didFinishSavingWithError error: NSErrorPointer, contextInfo:UnsafePointer<Void>) {
        
        if error != nil {
            let alert = UIAlertController(title: "Save Failed", message: "Failed to save image", preferredStyle: UIAlertControllerStyle.Alert)
            let cancelAction = UIAlertAction(title: "OK", style: .Cancel, handler: nil)
            alert.addAction(cancelAction)
            self.presentViewController(alert, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Image Saved", message: "Image Saved", preferredStyle: UIAlertControllerStyle.Alert)
            let okAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(okAction)
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }
    
    // Called when you touch the Cancel button in any of the 3 contexts - camera, camera roll or photo library.
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}

