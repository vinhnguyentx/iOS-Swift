//
//  PanViewController.swift
//  TestGestureRecognizers1Swift
//
//  Created by Robert Seitsinger on 3/28/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class PanViewController: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Pan Gesture Recognizer"
        
        // Create the recognizer.
        let recognizer = UIPanGestureRecognizer()
        recognizer.addTarget(self, action: #selector(PanViewController.panView(_:)))
        
        // Associate the recognizer with the view.
        self.myView.addGestureRecognizer(recognizer)
        self.myView.userInteractionEnabled = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func panView(sender:UIPanGestureRecognizer) {
        
        let translation = sender.translationInView(self.view)
        
        if let view = sender.view {
            view.center = CGPoint(x:view.center.x + translation.x,
                                  y:view.center.y + translation.y)
        }
        
        sender.setTranslation(CGPointZero, inView: self.view)
    }
}
