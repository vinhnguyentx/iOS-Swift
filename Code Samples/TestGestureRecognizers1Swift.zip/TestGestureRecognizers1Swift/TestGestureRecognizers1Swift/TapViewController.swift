//
//  TapViewController.swift
//  TestGestureRecognizers1Swift
//
//  Created by Robert Seitsinger on 11/5/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class TapViewController: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    private let adjustX:CGFloat = 75.0
    private let adjustY:CGFloat = 50.0
    private var lblOriginalSize:CGSize = CGSize(width: 0, height: 0)
    private var lblCurrentSize:CGSize =  CGSize(width: 0, height: 0)
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Tap Gesture Recognizer"
        
//        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title:"< BackBob", style:.Plain, target:self, action:nil)
        
        // Remember the original width
        self.lblOriginalSize = self.myView.frame.size
        self.lblCurrentSize = self.myView.frame.size
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tapGestureRecognizer(sender: UITapGestureRecognizer) {
        
        let currentCenter = self.myView.center
        
        UIView.animateWithDuration(0.5,
            delay: 0,
            options: UIViewAnimationOptions.CurveLinear,
            animations: {
                var frame = self.myView.frame
                if self.myView.frame.size.width == self.lblOriginalSize.width {
                    frame.size = CGSize(width: self.lblOriginalSize.width + self.adjustX, height: self.lblOriginalSize.height + self.adjustY)
                } else {
                    frame.size = self.lblOriginalSize
                }
                self.myView.frame = frame
                self.myView.center = currentCenter
            },
            completion: nil)
    }
    
}
