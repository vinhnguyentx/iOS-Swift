//
//  SwipeViewController.swift
//  TestGestureRecognizers1Swift
//
//  Created by Robert Seitsinger on 11/5/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class SwipeViewController: UIViewController {

    var myViewMiddleWidth:CGFloat = 0
    
    @IBOutlet weak var myViewMiddle: UIView!
    @IBOutlet weak var myViewLeft: UIView!
    @IBOutlet weak var myViewRight: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Swipe Gesture Recognizer"
        
        self.myViewMiddleWidth = self.myViewMiddle.frame.size.width
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func swipeGestureRight(sender: AnyObject) {
        // Move all the views at once
        UIView.animateWithDuration(0.5,
            delay: 0,
            options: UIViewAnimationOptions.CurveLinear,
            animations: {
                self.myViewMiddle.frame = CGRectOffset(self.myViewMiddle.frame, self.myViewMiddleWidth, 0.0);
                self.myViewLeft.frame = CGRectOffset(self.myViewLeft.frame, self.myViewMiddleWidth, 0.0);
                self.myViewRight.frame = CGRectOffset(self.myViewRight.frame, self.myViewMiddleWidth, 0.0);
            },
            completion: nil)
        // Move some of the views at different times.
//        UIView.animateWithDuration(0.5,
//            delay: 0.25,
//            options: UIViewAnimationOptions.CurveLinear,
//            animations: {
//                self.myViewLeft.frame = CGRectOffset(self.myViewLeft.frame, self.myViewMiddleWidth, 0.0);
//            },
//            completion: nil)
//        UIView.animateWithDuration(0.5,
//            delay: 0.25,
//            options: UIViewAnimationOptions.CurveLinear,
//            animations: {
//                self.myViewRight.frame = CGRectOffset(self.myViewRight.frame, self.myViewMiddleWidth, 0.0);
//            },
//            completion: nil)
    }
    
    @IBAction func swipeGestureLeft(sender: AnyObject) {
        UIView.animateWithDuration(0.5,
            delay: 0,
            options: UIViewAnimationOptions.CurveLinear,
            animations: {
                self.myViewLeft.frame = CGRectOffset(self.myViewLeft.frame, -self.myViewMiddleWidth, 0.0);
                self.myViewMiddle.frame = CGRectOffset(self.myViewMiddle.frame, -self.myViewMiddleWidth, 0.0);
                self.myViewRight.frame = CGRectOffset(self.myViewRight.frame, -self.myViewMiddleWidth, 0.0);
            },
            completion: nil)
    }
    
}
