//
//  RotateViewController.swift
//  TestGestureRecognizers1Swift
//
//  Created by Robert Seitsinger on 3/28/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class RotateViewController: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Rotate Gesture Recognizer"

        // Create the recognizer.
        let recognizer = UIRotationGestureRecognizer()
        recognizer.addTarget(self, action: #selector(RotateViewController.rotateView(_:)))

        // Associate the recognizer with the view.
        self.myView.addGestureRecognizer(recognizer)
        self.myView.userInteractionEnabled = true
        self.myView.multipleTouchEnabled = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func rotateView(sender:UIRotationGestureRecognizer) {
        self.myView.transform = CGAffineTransformRotate(self.myView.transform, sender.rotation)
        sender.rotation = 0.0
    }
}
