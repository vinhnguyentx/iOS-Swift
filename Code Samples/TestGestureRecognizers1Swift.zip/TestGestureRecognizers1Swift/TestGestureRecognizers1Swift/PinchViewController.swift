//
//  PinchViewController.swift
//  TestGestureRecognizers1Swift
//
//  Created by Robert Seitsinger on 3/28/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class PinchViewController: UIViewController {

    @IBOutlet weak var myView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Pinch Gesture Recognizer"
        
        // Create the recognizer.
        let recognizer = UIPinchGestureRecognizer()
        recognizer.addTarget(self, action: #selector(PinchViewController.pinchView(_:)))
        
        // Associate the recognizer with the view.
        self.myView.addGestureRecognizer(recognizer)
        self.myView.userInteractionEnabled = true
        self.myView.multipleTouchEnabled = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pinchView(sender:UIPinchGestureRecognizer) {
        self.myView.transform = CGAffineTransformScale(self.myView.transform, sender.scale, sender.scale);
        sender.scale = 1.0;
    }
}
