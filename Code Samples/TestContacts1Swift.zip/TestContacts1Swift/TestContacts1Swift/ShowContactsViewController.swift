//
//  ShowContactsViewController.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class ShowContactsViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtFieldName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Show Contacts"
        
        self.txtFieldName.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        let viewController = segue.destinationViewController as! MyTableViewController
        
        // Pass the selected contact to the detail view controller.
        viewController.searchName = self.txtFieldName.text
    }

    // MARK: UITextFieldDelegate functions
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Dismisses keyboard when touching anywhere by a text field and the keyboard.
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
}
