//
//  AddContactViewController.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit
import Contacts

class AddContactViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var txtFieldEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Add Contact"

        self.txtFieldName.becomeFirstResponder()
        self.txtFieldName.delegate = self
        self.txtFieldEmail.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnAddContactAction(sender: AnyObject) {
        let newContact = CNMutableContact()
        
        newContact.givenName = self.txtFieldName.text!
        
        let homeEmail = CNLabeledValue(label: CNLabelHome, value: self.txtFieldEmail.text!)
        newContact.emailAddresses = [homeEmail]
        
        do {
            let saveRequest = CNSaveRequest()
            saveRequest.addContact(newContact, toContainerWithIdentifier: nil)
            
            try AppDelegate.getAppDelegate().contactStore.executeSaveRequest(saveRequest)
            
            AppDelegate.getAppDelegate().showMessage("Contact Added!")
        }
        catch {
            AppDelegate.getAppDelegate().showMessage("Unable to save the new contact.")
        }
    }
    
    // MARK: UITextFieldDelegate functions
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    // Dismisses keyboard when touching anywhere by a text field and the keyboard.
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

}
