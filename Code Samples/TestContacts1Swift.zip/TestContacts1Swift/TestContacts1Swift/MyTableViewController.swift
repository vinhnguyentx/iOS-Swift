//
//  MyTableViewController.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit
import Contacts

class MyTableViewController: UITableViewController {

    var searchName:String? = nil
    var myContacts:[CNContact] = [CNContact]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Show Contacts"
        
        // For demo purposes, fetch all the contacts for "Bob".
        self.fetchSomeContacts(searchName!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Fetch some contacts.
    func fetchSomeContacts(searchName:String) {
        AppDelegate.getAppDelegate().requestForAccess { (accessGranted) -> Void in
            if accessGranted {
                let predicate = CNContact.predicateForContactsMatchingName(searchName)
                // let keys = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactEmailAddressesKey, CNContactBirthdayKey, CNContactImageDataKey]
                
                // The descriptorForRequiredKeysForStyle is used here to avoid having to enter all the
                // individual keys related to the name parts to get the full name. All the related keys are
                // specified by a key descriptor, and the descriptor is used instead of single keys.
                let keys = [CNContactFormatter.descriptorForRequiredKeysForStyle(CNContactFormatterStyle.FullName), CNContactEmailAddressesKey, CNContactBirthdayKey, CNContactImageDataKey]
                var contacts = [CNContact]()
                var message: String!
                
                let contactsStore = AppDelegate.getAppDelegate().contactStore
                do {
                    contacts = try contactsStore.unifiedContactsMatchingPredicate(predicate, keysToFetch: keys)
                    
                    if contacts.count == 0 {
                        message = "No contacts were found matching the given name."
                    }
                } catch {
                    message = "Unable to fetch contacts."
                }
                
                if message != nil {
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        AppDelegate.getAppDelegate().showMessage(message)
                    })
                } else {
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        self.myContacts = contacts   // Remember the returned contacts.
                        self.tableView.reloadData()  // Update the table view with the contacts.
                    })
                }
            }
        }
    }
    
    func refetchContact(contact contact: CNContact, atIndexPath indexPath: NSIndexPath) {
        AppDelegate.getAppDelegate().requestForAccess { (accessGranted) -> Void in
            if accessGranted {
                let keys = [CNContactFormatter.descriptorForRequiredKeysForStyle(CNContactFormatterStyle.FullName), CNContactEmailAddressesKey, CNContactBirthdayKey, CNContactImageDataKey]
                
                do {
                    let contactRefetched = try AppDelegate.getAppDelegate().contactStore.unifiedContactWithIdentifier(contact.identifier, keysToFetch: keys)
                    // Update the specific contact.
                    self.myContacts[indexPath.row] = contactRefetched
                    
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        // Update the specific row in the table for the contact.
                        self.tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
                    })
                }
                catch {
                    print("Unable to refetch the contact: \(contact)", separator: "", terminator: "\n")
                }
            }
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.myContacts.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cellid", forIndexPath: indexPath) as! MyTableViewCell

        // Alternate background colors for the cells.
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = UIColor.lightGrayColor()
        } else {
            cell.backgroundColor = UIColor.grayColor()
        }
        
        // Get the contact to display in this cell.
        let currentContact = self.myContacts[indexPath.row]
        
        // Make sure all the data components are there. If not, refetch.
        if !currentContact.isKeyAvailable(CNContactBirthdayKey) ||
           !currentContact.isKeyAvailable(CNContactImageDataKey) ||
           !currentContact.isKeyAvailable(CNContactEmailAddressesKey) {
            refetchContact(contact: currentContact, atIndexPath: indexPath)
        } else {
            // Use the built-in contact name formatter to format the name.
            cell.lblName.text = CNContactFormatter.stringFromContact(currentContact, style: .FullName)
            
            // Set the birthday info.
            if let birthday = currentContact.birthday {
//                cell.lblBirthday.text = "\(birthday.year)-\(birthday.month)-\(birthday.day)"
                cell.lblBirthday.text = AppDelegate.getAppDelegate().getDateStringFromComponents(birthday)
            } else {
                cell.lblBirthday.text = "No available birthday data"
            }
            
            // Set the contact image.
            if let imageData = currentContact.imageData {
                cell.myImageView.image = UIImage(data: imageData)
            } else {
                cell.myImageView.image = nil
            }
        }

        return cell
    }

    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80.0
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

        // Get the new view controller using segue.destinationViewController.
        let viewController = segue.destinationViewController as! DetailViewController
        
        // Pass the selected contact to the detail view controller.
        let indexPath = self.tableView.indexPathForCell(sender as! MyTableViewCell)
        viewController.contact = self.myContacts[indexPath!.row]
    }

}
