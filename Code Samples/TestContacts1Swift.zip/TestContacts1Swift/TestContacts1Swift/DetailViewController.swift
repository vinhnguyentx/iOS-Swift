//
//  DetailViewController.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit
import Contacts

class DetailViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var lblBirthday: UILabel!
    
    var contact:CNContact? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Contact Detail"
        
        self.lblName.text = CNContactFormatter.stringFromContact(contact!, style: .FullName)
        
        if contact!.isKeyAvailable(CNContactBirthdayKey) {
            // Set the birthday info.
            if let birthday = contact!.birthday {
//                self.lblBirthday.text = "\(birthday.year)-\(birthday.month)-\(birthday.day)"
                self.lblBirthday.text = AppDelegate.getAppDelegate().getDateStringFromComponents(birthday)
            } else {
                self.lblBirthday.text = "No available birthday data"
            }
        }
        
        if contact!.isKeyAvailable(CNContactBirthdayKey) {
            // Set the contact image.
            if let imageData = contact!.imageData {
                self.myImageView.image = UIImage(data: imageData)
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
