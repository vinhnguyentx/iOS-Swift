//
//  MainViewController.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Contacts Demo"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
