//
//  AppDelegate.swift
//  TestContacts1Swift
//
//  Created by Robert Seitsinger on 4/13/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit
import Contacts

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    // Create the one and only contact store object; which we'll use throughout the app.
    var contactStore = CNContactStore()

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    // MARK: Custom functions
    
    class func getAppDelegate() -> AppDelegate {
        return UIApplication.sharedApplication().delegate as! AppDelegate
    }

    func showMessage(message: String) {
        let alertController = UIAlertController(title: "Contacts Demo Message", message: message, preferredStyle: UIAlertControllerStyle.Alert)
        
        let dismissAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action) -> Void in
        }
        
        alertController.addAction(dismissAction)
        
        // Get the list of view controllers in the navigation controller view controlle stack.
        let pushedViewControllers = (self.window?.rootViewController as! UINavigationController).viewControllers
        // Get the most recent view controller pushed. This is what we'll use to present the alert.
        let presentedViewController = pushedViewControllers[pushedViewControllers.count - 1]
        
        presentedViewController.presentViewController(alertController, animated: true, completion: nil)
    }
    
    func requestForAccess(completionHandler: (accessGranted: Bool) -> Void) {
        
        let authorizationStatus = CNContactStore.authorizationStatusForEntityType(CNEntityType.Contacts)
        
        switch authorizationStatus {
            case .Authorized:
                // We've already been authorized, so, just execute the completion handler.
                completionHandler(accessGranted: true)
                
            case .Denied, .NotDetermined:
                // Request authorization.
                self.contactStore.requestAccessForEntityType(CNEntityType.Contacts, completionHandler: { (access, accessError) -> Void in
                    if access {
                        completionHandler(accessGranted: access)
                    } else {
                        if authorizationStatus == CNAuthorizationStatus.Denied {
                            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                let message = "\(accessError!.localizedDescription)\n\nPlease allow the app to access your contacts through the Settings."
                                self.showMessage(message)
                            })
                        }
                    }
                })
                
            case .Restricted:
                // The application is not authorized to access contact data.
                // Call the completion handler indicating such.
                completionHandler(accessGranted: false)
        }
    }

    func getDateStringFromComponents(dateComponents: NSDateComponents) -> String! {
        if let date = NSCalendar.currentCalendar().dateFromComponents(dateComponents) {
            let dateFormatter = NSDateFormatter()
            dateFormatter.locale = NSLocale.currentLocale()
            dateFormatter.dateStyle = NSDateFormatterStyle.FullStyle
            let dateString = dateFormatter.stringFromDate(date)
            
            return dateString
        }
        
        return nil
    }

}

