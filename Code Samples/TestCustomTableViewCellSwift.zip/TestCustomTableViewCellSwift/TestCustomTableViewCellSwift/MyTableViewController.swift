//
//  MyTableViewController.swift
//  TestCustomTableViewCellSwift
//
//  Created by Robert Seitsinger on 2/8/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class MyTableViewController: UITableViewController {

    var people:[Person] = [Person]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Custom Table View Cell App"

        self.loadDataModel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func loadDataModel() {
        self.people.append(Person(firstName: "Joe", lastName: "Johnson", age: 35))
        self.people.append(Person(firstName: "Sam", lastName: "Smith", age: 27))
        self.people.append(Person(firstName: "Sue", lastName: "Jefferson", age: 52))
        self.people.append(Person(firstName: "Zoey", lastName: "Zimmerman", age: 17))
        self.people.append(Person(firstName: "Alan", lastName: "Albright", age: 83))
        self.people.append(Person(firstName: "Chris", lastName: "Chambers", age: 33))
        self.people.append(Person(firstName: "Danny", lastName: "Donaldson", age: 6))
        self.people.append(Person(firstName: "Eli", lastName: "Edgerton", age: 10))
        self.people.append(Person(firstName: "Frank", lastName: "Farmer", age: 100))
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: (NSIndexPath!)) -> CGFloat {

        // Toggle the cell height - alternating between rows.
        let cellSelector = indexPath.row % 2
        
        if cellSelector == 0 {
            return 95
        } else {
            return 120
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.people.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let person = self.people[indexPath.row]
        
        let cellSelector = indexPath.row % 2
        
        // Toggle the cell to use - alternating between rows.
        if cellSelector == 0 {
            let cell:MyTableViewCell1 = tableView.dequeueReusableCellWithIdentifier("cellid1", forIndexPath: indexPath) as! MyTableViewCell1
            cell.label11.text = person.firstName
            cell.label12.text = person.lastName
            return cell
        } else {
            let cell = tableView.dequeueReusableCellWithIdentifier("cellid2", forIndexPath: indexPath) as! MyTableViewCell2
            cell.label21.text = person.firstName
            cell.label22.text = person.lastName
            return cell
        }
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        // Get the new view controller using segue.destinationViewController.
//        // Pass the selected object to the new view controller.
//    }

}
