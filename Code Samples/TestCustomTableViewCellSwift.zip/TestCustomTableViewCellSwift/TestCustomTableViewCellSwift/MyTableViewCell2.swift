//
//  MyTableViewCell2.swift
//  TestCustomTableViewCellSwift
//
//  Created by Robert Seitsinger on 2/8/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class MyTableViewCell2: UITableViewCell {

    @IBOutlet weak var label21: UILabel!
    @IBOutlet weak var label22: UILabel!
    @IBOutlet weak var button: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func btnAction(sender: AnyObject) {
        print("You touched the cell 2 button")
    }
    
}
