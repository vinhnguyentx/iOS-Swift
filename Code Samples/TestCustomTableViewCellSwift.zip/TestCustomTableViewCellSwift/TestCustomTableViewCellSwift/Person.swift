//
//  Person.swift
//  TestCustomTableViewCellSwift
//
//  Created by Robert Seitsinger on 2/8/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import Foundation

class Person {
    var firstName:String = "<not set>"
    var lastName:String = "<not set>"
    var age:Int = 0
    
    init(firstName:String, lastName:String, age:Int) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
    }
}