//
//  CalendarDetailViewController.swift
//  TestEventKit1Swift
//
//  Created by Robert Seitsinger on 11/17/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import EventKit

class CalendarDetailViewController: UIViewController {

    var calendar: EKCalendar?

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSource: UILabel!
    @IBOutlet weak var lblIdentifier: UILabel!
    @IBOutlet weak var lblType: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Calendar Detail"

        // Populate the calendar data
        if let calendar = calendar {
            lblTitle.text = calendar.title
            lblSource.text = sourceTypeDescription(calendar.source)
            lblIdentifier.text = calendar.calendarIdentifier
            lblType.text = typeDescription(calendar.type)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    func sourceTypeDescription(source:EKSource) -> String {
        var description:String = ""
        
        switch (source.sourceType) {
            case EKSourceType.Local:
                description = "Local : \(source.title)"
            case EKSourceType.Exchange:
                description = "Exchange : \(source.title)"
            case EKSourceType.CalDAV:
                description = "CalDAV : \(source.title)"
            case EKSourceType.MobileMe:
                description = "MobileMe : \(source.title)"
            case EKSourceType.Subscribed:
                description = "Subscribed : \(source.title)"
            case EKSourceType.Birthdays:
                description = "Birthdays : \(source.title)"
        }

        return description
    }

    func typeDescription(type:EKCalendarType) -> String {
        var description:String = ""
        
        switch (type) {
            case EKCalendarType.Local:
                description = "Local"
            case EKCalendarType.Exchange:
                description = "Exchange"
            case EKCalendarType.CalDAV:
                description = "CalDAV"
            case EKCalendarType.Subscription:
                description = "Subscription"
            case EKCalendarType.Birthday:
                description = "Birthday"
        }
        
        return description
    }
    
}
