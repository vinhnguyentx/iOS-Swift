//
//  CalendarListTableViewController.swift
//  TestEventKit1Swift
//
//  Created by Robert Seitsinger on 11/17/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import EventKit

class CalendarListViewController: UITableViewController {
    
    let eventStore = EKEventStore()
    
    var calendars: [EKCalendar]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Calendars"
    }
    
    override func viewWillAppear(animated: Bool) {
        // Do this here because the user can change access to the calendar at any time.
        // So, we should check each time the UI is displayed to the user.
        checkCalendarAuthorizationStatus()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func checkCalendarAuthorizationStatus() {
        
        // EKEntityType.Event corresponds to the user's calendar.
        // EKEntityType.Reminder corresponds to the user's reminders.
        let status = EKEventStore.authorizationStatusForEntityType(EKEntityType.Event)
        
        switch (status) {
            case EKAuthorizationStatus.NotDetermined:
                // This happens on first-run
                self.requestAccessToCalendar()
            case EKAuthorizationStatus.Authorized:
                // Things are ok to show the calendars in the table view
                self.showCalendars()
            case EKAuthorizationStatus.Restricted, EKAuthorizationStatus.Denied:
                // Help the user given us permission to access the calendar
                self.needPermission()
        }
    }
    
    func requestAccessToCalendar() {
        eventStore.requestAccessToEntityType(EKEntityType.Event, completion: {
            (accessGranted: Bool, error: NSError?) in
            
            if accessGranted == true {
                dispatch_async(dispatch_get_main_queue(), {
                    self.showCalendars()
                })
            } else {
                self.needPermission()
            }
        })
    }
    
    func showCalendars() {
        // Get the list of calendars.
        self.calendars = eventStore.calendarsForEntityType(EKEntityType.Event)
        
        // Force an update of the table view.
        self.tableView.reloadData()
    }
    
    func needPermission() {
        // Display an alert controller, telling the user what we need.
        dispatch_async(dispatch_get_main_queue(), {
            let alertController = UIAlertController(title: "Calendar Access", message: "You need to enable access to the calendar. Touch Ok to go to the setting.", preferredStyle: UIAlertControllerStyle.Alert)
            
            let CancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action:UIAlertAction) in
            }
            alertController.addAction(CancelAction)
            
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action:UIAlertAction) in
                // Help the user given us permission to access the calendar, by navigating them to the relevant setting.
                let openSettingsUrl = NSURL(string: UIApplicationOpenSettingsURLString)
                UIApplication.sharedApplication().openURL(openSettingsUrl!)
            }
            alertController.addAction(OKAction)
            
            self.presentViewController(alertController, animated: true, completion:nil)
        })
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let calendars = self.calendars {
            return calendars.count
        }
        return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("CalListCellId", forIndexPath: indexPath)
        
        if let calendars = self.calendars {
            cell.textLabel?.text = calendars[indexPath.row].title
        } else {
            cell.textLabel?.text = "Unknown Calendar Name"
        }
        
        return cell
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        let indexPath:NSIndexPath? = self.tableView!.indexPathForSelectedRow
        
        // Get the destination view controller
        let detailVC:CalendarDetailViewController = segue.destinationViewController as! CalendarDetailViewController
        
        // Pass in the selected calendar object
        detailVC.calendar = self.calendars![indexPath!.row]
    }
    
}
