//
//  MainViewController.swift
//  TestEventKit1Swift
//
//  Created by Robert Seitsinger on 11/17/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import EventKit

class MainViewController: UIViewController {

    let eventStore = EKEventStore();
    let calendarIdKey = "MyNewCalendarIdKey"
    let calendarTitle = "My New Calendar"

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Event Kit Demo"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnCreateCalendarAction(sender: AnyObject) {
        
        // Use Event Store to create a new calendar instance.
        // Configure its title.
        let newCalendar = EKCalendar(forEntityType: EKEntityType.Event, eventStore: eventStore)
        newCalendar.title = calendarTitle
        
        // Access list of available sources from the Event Store
        let sourcesInEventStore = eventStore.sources 
        
        // Filter the available sources and select the "Local" source to assign to the new calendar's source property
        newCalendar.source = sourcesInEventStore.filter{
            (source: EKSource) -> Bool in
            source.sourceType == EKSourceType.Local
            }.first!
        
        // Save the calendar using the Event Store instance
        do {
            try eventStore.saveCalendar(newCalendar, commit: true)
            
            // Store the calendar id locally. To allow us to get this calendar later.
            NSUserDefaults.standardUserDefaults().setObject(newCalendar.calendarIdentifier, forKey: calendarIdKey)

            let alert = UIAlertController(title: "Calendar Saved", message: "Calendar was successfully saved", preferredStyle: .Alert)
            let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(OKAction)
            
            self.presentViewController(alert, animated: true, completion: nil)
       } catch _ {
            let alert = UIAlertController(title: "Calendar Save Error", message: "Calendar could not be saved", preferredStyle: .Alert)
            let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
            alert.addAction(OKAction)
            
            self.presentViewController(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func btnAddEventAction(sender: AnyObject) {
        let calendars = eventStore.calendarsForEntityType(EKEntityType.Event)
        
        // Iterate through the calendars, looking for our new calendar.
        // One way to get the calendar you're looking for.
        for calendar in calendars {
            if calendar.title == calendarTitle {
                // Starting time is now.
                let startDate = NSDate()
                // Ending time is 2 hours from now.
                let endDate = startDate.dateByAddingTimeInterval(2 * 60 * 60)
                
                // Create calendar event object.
                let event = EKEvent(eventStore: eventStore)
                event.calendar = calendar
                event.title = "New Meeting"
                event.startDate = startDate
                event.endDate = endDate
                
                // Save the event in our new calendar.
                do {
                    try eventStore.saveEvent(event, span: EKSpan.ThisEvent)
                    
                    let alert = UIAlertController(title: "Event Saved", message: "Event was successfully saved", preferredStyle: .Alert)
                    let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                    alert.addAction(OKAction)
                    
                    self.presentViewController(alert, animated: true, completion: nil)
                } catch _ {
                    let alert = UIAlertController(title: "Event Save Error", message: "Event could not be saved", preferredStyle: .Alert)
                    let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                    alert.addAction(OKAction)
                    
                    self.presentViewController(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    @IBAction func btnDeleteCalendarAction(sender: AnyObject) {
        // Get the calendar identifier we stored earlier.
        let calendarIdentifier = NSUserDefaults.standardUserDefaults().stringForKey(calendarIdKey)

        // Get the calendar associated with the stored calendar identifier.
        // Another way to get the calendar you're looking for.
        let calendar = eventStore.calendarWithIdentifier(calendarIdentifier!);
        
        if (calendar != nil) {
            // Delete our new Calendar.
            do {
                try eventStore.removeCalendar(calendar!, commit: true)
                
                let alert = UIAlertController(title: "Calendar Deleted", message: "Calendar was successfully deleted", preferredStyle: .Alert)
                let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                alert.addAction(OKAction)
                
                self.presentViewController(alert, animated: true, completion: nil)
            } catch _ {
                let alert = UIAlertController(title: "Calendar Delete Error", message: "Calendar could not be deleted", preferredStyle: .Alert)
                let OKAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                alert.addAction(OKAction)
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
    }
    
}
