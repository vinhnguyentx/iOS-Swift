//
//  TravelPath.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/15/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation
import MapKit

class TravelPath {
    
    private var path: [CLLocationCoordinate2D] = []
    
    init() {
        // Create the list of coordinates to travel that define a path
        // Latitude is North/South (vertical); Longitude is East/West (horizontal).
        self.add(latitude: 30.267153, longitude: -97.743061) // starting in Austin, TX
        self.add(latitude: 30.267153, longitude: -97.748)    // moving west
        self.add(latitude: 30.277153, longitude: -97.753061) // moving north, west.
    }
    
    func count() -> Int {
        return path.count
    }
    
    func get(index index:Int) -> CLLocationCoordinate2D {
        if index < path.count {
            return path[index]
        } else {
            return CLLocationCoordinate2DMake(30.267153, -97.743061) //  Austin, TX
        }
    }
    
    func getPath() -> [CLLocationCoordinate2D] {
        return self.path
    }

    func add(latitude latitude:CLLocationDegrees, longitude:CLLocationDegrees) {
        path.append(CLLocationCoordinate2DMake(latitude, longitude))
    }
    
    func delete(index index:Int) {
        if index < path.count {
            path.removeAtIndex(index)
        }
    }
}
