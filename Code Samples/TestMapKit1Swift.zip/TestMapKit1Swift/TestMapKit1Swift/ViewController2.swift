//
//  ViewController2.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/15/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import MapKit

class ViewController2: UIViewController, MKMapViewDelegate {

    let travelPath = TravelPath()
    var config = Config.sharedInstance

    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Travel Path"
        
        // Center on the first coordinate - the starting point
        let pathCoord = travelPath.get(index: 0)
        let initialLocation = CLLocation(latitude: pathCoord.latitude, longitude: pathCoord.longitude)
        
        centerMapOnLocation(initialLocation)
        
        self.mapView.delegate = self
        self.mapView.mapType = config.mapType
        
        // Define our travel path overlay.
        let pointCount = travelPath.count()
        var pointsToUse: [CLLocationCoordinate2D] = travelPath.getPath()

        let myPolyline = MKPolyline(coordinates: &pointsToUse, count: pointCount)
        
        mapView.addOverlay(myPolyline)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func centerMapOnLocation(location: CLLocation) {
        
        let latitudeMeters = config.regionRadius * config.regionRadiusMultiplier
        let longitudeMeters = config.regionRadius * config.regionRadiusMultiplier
        
        // The first argument - location - is the centerpoint
        // The second and third arguments indicate the distance in meters from that centerpoint to show
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, latitudeMeters, longitudeMeters)
        
        // setRegion tells mapView to display the region
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    // This gets called for every annotation you add to the map. Returns the view for a given annotation.
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? Artwork {
            let identifier = "pin"
            var view: MKPinAnnotationView
            if let dequeuedView = mapView.dequeueReusableAnnotationViewWithIdentifier(identifier) as? MKPinAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
            } else {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.canShowCallout = true
                view.calloutOffset = CGPoint(x: -5, y: 5)
                view.pinTintColor = UIColor.purpleColor()
                view.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure) as UIView
            }
            return view
        }
        return nil
    }

    // This method returns a view for the drawing of the travel path
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        let lineView = MKPolylineRenderer(overlay: overlay)
        lineView.strokeColor = UIColor.greenColor()
        
        return lineView
    }
    
}
