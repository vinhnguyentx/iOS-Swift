//
//  CityLatLongs.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/15/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

class CityLatLongs {
    
    private var list:[CityLatLong] = [CityLatLong]()
    
    init() {
        // Create the list of people
        list.append(CityLatLong(city:"Austin", state:"TX", latitude:30.267153, longitude:-97.743061))
        list.append(CityLatLong(city:"Honolulu", state:"HA", latitude:21.282778, longitude:-157.829444))
        list.append(CityLatLong(city:"London", state:"GB", latitude:51.507351, longitude:-0.127758))
    }
    
    func count() -> Int {
        return list.count
    }
    
    func get(index index:Int) -> CityLatLong {
        if index < list.count {
            return list[index]
        } else {
            return CityLatLong(city:"Austin", state:"TX", latitude:30.267153, longitude:-97.743061)
        }
    }
    
    func add(city:String, state:String, latitude:Double, longitude:Double) {
        list.append(CityLatLong(city:city, state:state, latitude:latitude, longitude:longitude))
    }
    
    func delete(index index:Int) {
        if index < list.count {
            list.removeAtIndex(index)
        }
    }
}
