//
//  CityLatLong.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/15/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

class CityLatLong {
    
    private var _city:String = ""
    private var _state:String = ""
    private var _latitude:Double = 0.0
    private var _longitude:Double = 0.0
    
    var city:String {
        get { return _city }
        set (newValue) { _city = newValue }
    }
    var state:String {
        get { return _state }
        set (newValue) { _state = newValue }
    }
    var latitude:Double {
        get { return _latitude }
        set (newValue) { _latitude = newValue }
    }
    var longitude:Double {
        get { return _longitude }
        set (newValue) { _longitude = newValue }
    }
    
    init(city:String, state:String, latitude:Double, longitude:Double) {
        self.city = city
        self.state = state
        self.latitude = latitude
        self.longitude = longitude
    }
    
    func description() -> String {
        return "City: \(city), State: \(state), Latitude: \(latitude), Longitude: \(longitude)"
    }
}
