//
//  Config.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/15/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation
import MapKit

// This is a Singleton
class Config {
    static let sharedInstance = Config()
    
    // map types:
    //  .Standard
    //  .Satellite
    //  .Hybrid
    //  .SatelliteFlyover (iOS 9)
    //  .HybridFlyover (iOS 9)

    private var _mapType:MKMapType = .Hybrid
    private var _regionRadius:Double = 0
    private var _regionRadiusMultiplier:Double = 0.0
    
    var mapType:MKMapType {
        get { return _mapType }
        set (newValue) { _mapType = newValue }
    }
    var regionRadius:Double {
        get { return _regionRadius }
        set (newValue) { _regionRadius = newValue }
    }
    var regionRadiusMultiplier:Double {
        get { return _regionRadiusMultiplier }
        set (newValue) { _regionRadiusMultiplier = newValue }
    }
    
    init(regionRadius:Double, regionRadiusMultiplier:Double) {
        self.regionRadius = regionRadius
        self.regionRadiusMultiplier = regionRadiusMultiplier
    }
    
    convenience init() {
        self.init(regionRadius:1000.0, regionRadiusMultiplier:2.0)
    }
    
    func description() -> String {
        return "Region Radius: \(regionRadius), Region Radius: \(regionRadiusMultiplier)"
    }
}
