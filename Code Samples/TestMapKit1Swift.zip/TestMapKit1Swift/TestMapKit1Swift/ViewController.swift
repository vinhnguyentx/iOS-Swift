//
//  ViewController.swift
//  TestMapKit1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    let dataModel = CityLatLongs()
    var config = Config.sharedInstance
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Annotation"
        
        // set starting coordinates
        let cityLatLong = dataModel.get(index: 1)
        let initialLocation = CLLocation(latitude: cityLatLong.latitude, longitude: cityLatLong.longitude)
        
        centerMapOnLocation(initialLocation)
        
        self.mapView.delegate = self
        self.mapView.mapType = config.mapType
        
        // Define one art work annotation and add it to the map.
        // This is for Hawaii.
        let artwork = Artwork(title: "King David Kalakaua",
            locationName: "Waikiki Gateway Park",
            discipline: "Sculpture",
            coordinate: CLLocationCoordinate2D(latitude: 21.283921, longitude: -157.831661))
        
        mapView.addAnnotation(artwork)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func centerMapOnLocation(location: CLLocation) {
        
        let latitudeMeters = config.regionRadius * config.regionRadiusMultiplier
        let longitudeMeters = config.regionRadius * config.regionRadiusMultiplier
        
        // The first argument - location - is the centerpoint
        // The second and third arguments indicate the distance in meters from that centerpoint to show
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, latitudeMeters, longitudeMeters)
        
        // setRegion tells mapView to display the defined region
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    // This gets called for every annotation you add to the map. Returns the view for a given annotation.
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? Artwork {
            let identifier = "pin"
            var view: MKPinAnnotationView
            if let dequeuedView = mapView.dequeueReusableAnnotationViewWithIdentifier(identifier) as? MKPinAnnotationView {
                    dequeuedView.annotation = annotation
                    view = dequeuedView
            } else {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.canShowCallout = true
                view.calloutOffset = CGPoint(x: -5, y: 5)
                view.pinTintColor = UIColor.purpleColor()
                view.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure) as UIView
            }
            return view
        }
        return nil
    }
}

