//
//  Config.swift
//  TestUserDefaults2Swift
//
//  Created by Robert Seitsinger on 10/3/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

class Config: NSObject {
    // Define keys for the values to store
    private static let kUserIdKey = "userId"
    private static let kNameKey = "name"
    
    class func setUserId(userId:Int) {
        NSUserDefaults.standardUserDefaults().setInteger(userId, forKey: kUserIdKey)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    class func setName(name:String) {
        NSUserDefaults.standardUserDefaults().setObject(name, forKey: kNameKey)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    class func userId() -> Int {
        return NSUserDefaults.standardUserDefaults().integerForKey(kUserIdKey)
    }
    class func name() -> String {
        return NSUserDefaults.standardUserDefaults().objectForKey(kNameKey) as! String
    }
}
