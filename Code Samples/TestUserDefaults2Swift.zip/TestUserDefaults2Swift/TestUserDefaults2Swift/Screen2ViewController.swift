//
//  Screen2ViewController.swift
//  TestUserDefaults2Swift
//
//  Created by Robert Seitsinger on 10/3/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class Screen2ViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Screen 2"

        // Get 'name' from the singleton Config object.
        self.lblName.text = Config.name()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
