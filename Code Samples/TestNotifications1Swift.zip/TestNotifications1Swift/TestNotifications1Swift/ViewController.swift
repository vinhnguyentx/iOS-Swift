//
//  ViewController.swift
//  TestNotifications1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblMessage: UILabel!
    
    var someOtherObject = RandomDoSomethingClass()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Notification Demo"

        // Define an observer for the notification
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "eventOneNotification1Handler:", name: eventOneHappenedNotificationKey, object: nil)

        // Define another observer for the notification; to show you there can be more than one
        // for a given notification.
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "eventOneNotification2Handler:", name: eventOneHappenedNotificationKey, object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    deinit {
        // You need to remove the observer before this object goes away.
        // This removes all registered observers for this object.
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    func eventOneNotification1Handler(notification: NSNotification) {
        print("eventOneNotification1Handler: Entry.")
        
        // wait - to prove this is a synchronous call
        sleep(2)
        
        // extract the data that was sent in the notification
        let dataDict:Dictionary<String,String> = notification.userInfo as! Dictionary<String,String>
        
        let data1 = dataDict["data1"]!
        let data2 = dataDict["data2"]!
        
        // update the label with the data
        lblMessage.text = "data1: [\(data1)], data2: [\(data2)]"

        print("eventOneNotification1Handler: Exit.")
    }
    
    func eventOneNotification2Handler(notification: NSNotification) {
        print("eventOneNotification2Handler: Entry.")
        
        // wait - to prove this is a synchronous call
        sleep(2)
        
        print("eventOneNotification2Handler: Exit.")
    }
    
}

