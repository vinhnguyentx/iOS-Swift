//
//  NextViewController.swift
//  TestNotifications1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {

    @IBOutlet weak var txtField1: UITextField!
    @IBOutlet weak var txtField2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSendNotificationAction(sender: UIButton) {
        print("btnSendNotificationAction: Entry.")
        
        // Get the data from the text fields
        let data1 = txtField1.text!
        let data2 = txtField2.text!
        
        // package the data into a dictionary
        let dataDict = ["data1":data1, "data2":data2];
        
        // Post the notification. send along the data.
        // We don't know who, if anyone, is listening. Nor should we care. We're just notifying.
        NSNotificationCenter.defaultCenter().postNotificationName(eventOneHappenedNotificationKey, object: nil, userInfo: dataDict)
        
        print("btnSendNotificationAction: Exit.")
    }

}
