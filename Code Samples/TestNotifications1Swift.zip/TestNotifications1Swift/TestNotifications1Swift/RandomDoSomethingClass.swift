//
//  RandomDoSomethingClass.swift
//  TestNotifications1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2016 cs378. All rights reserved.
//

import Foundation
import UIKit

// The class must derive from NSObject for notifications to work in a basic class.
class RandomDoSomethingClass : NSObject {
    override init() {
        super.init()
        
        // Define an observer for the notification
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "eventNotificationHandler:", name: eventOneHappenedNotificationKey, object: nil)
    }
    
    deinit {
        // You need to remove the observer before this object goes away.
        // This removes all registered observers for this object.
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func eventNotificationHandler(notification: NSNotification) {
        print("RandomDoSomethingClass:eventNotificationHandler: Entry.")
        
        // extract the data that was sent in the notification
        let dataDict:Dictionary<String,String> = notification.userInfo as! Dictionary<String,String>
        
        let data1 = dataDict["data1"]!
        let data2 = dataDict["data2"]!

        print("    data1: ", data1)
        print("    data2: ", data2)
        print("RandomDoSomethingClass:eventNotificationHandler: Exit.")
    }
}
