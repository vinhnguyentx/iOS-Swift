//
//  NotificationKeys.swift
//  TestNotifications1Swift
//
//  Created by Robert Seitsinger on 10/14/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

// Define one constant for each notification in the app
let eventOneHappenedNotificationKey = "eventOneHappenedNotificationKey"
