//
//  MyCollectionViewController.swift
//  TestCollectionView
//
//  Created by Robert Seitsinger on 9/17/15.
//  Copyright (c) 2015 cs378. All rights reserved.
//

import UIKit

class MyCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {

    private let reuseIdentifier = "cellid"
    private let sectionInsets = UIEdgeInsets(top: 25.0, left: 10.0, bottom: 25.0, right: 10.0)
    
    // Define and instantiate the data model object
    private var data:Pictures = Pictures()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: UICollectionViewDataSource

    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }

    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.data.count()
    }

    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as! MyCollectionViewCell
        
        // Set label and cell background colors
        cell.lblTitle.textColor = UIColor.blackColor()
    
        // Get which data model element to use
        let index:Int = indexPath.row

        // Get the image for this cell
        let picture:Picture = self.data.getPicture(index: index)

        // Set the cell to display the image
        cell.lblTitle.text = "Pic \(picture.getId())"
        cell.imgImageView.image = picture.getImage()
        
        return cell
    }

    // MARK: UICollectionViewDelegateFlowLayout

    // Responsible for telling the layout the size of a given cell
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
            
            let indexRow:Int = indexPath.row
            let image:UIImage = self.data.getPicture(index:indexRow).getImage()!
            
            var size = image.size
            
            // Make the image sizes small enough.
            // The images are 500-something x 300-something - we need them smaller.
            size.width *= 0.35
            size.height *= 0.35
            
            return size
    }
    
    // Returns the spacing between the cells, headers, and footers
    func collectionView(collectionView: UICollectionView,
        layout collectionViewLayout: UICollectionViewLayout,
        insetForSectionAtIndex section: Int) -> UIEdgeInsets {
            return sectionInsets
    }
}
