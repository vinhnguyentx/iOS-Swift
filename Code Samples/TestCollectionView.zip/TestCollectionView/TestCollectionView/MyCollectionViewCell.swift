//
//  MyCollectionViewCell.swift
//  TestCollectionView
//
//  Created by Robert Seitsinger on 9/17/15.
//  Copyright (c) 2015 cs378. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgImageView: UIImageView!
    
}
