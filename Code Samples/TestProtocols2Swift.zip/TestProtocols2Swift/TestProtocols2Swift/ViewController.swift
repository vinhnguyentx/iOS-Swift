//
//  ViewController.swift
//  TestProtocols2Swift
//
//  Created by Robert Seitsinger on 9/30/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var delegate:MyNotificationProtocol? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.title = "Protocols Demo"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnGoToScreen1Action(sender: AnyObject) {
        // Queue a task that will send a message to the delegate
        dispatch_async(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            // pause
            sleep(3)
            // Call the delegate with a message
            self.delegate?.notified("You've been notified - button 1 touched")
        }
    }

    @IBAction func btnGoToScreen2Action(sender: AnyObject) {
        // Queue a task that will send a message to the delegate
        dispatch_async(dispatch_get_global_queue(Int(QOS_CLASS_USER_INITIATED.rawValue), 0)) {
            // pause
            sleep(3)
            // Call the delegate with a message
            self.delegate?.notified("You've been notified - button 2 touched")
        }
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

        if segue.identifier == "GoToScreen1" {
            self.delegate = (segue.destinationViewController as? Screen1ViewController)!
        } else if segue.identifier == "GoToScreen2" {
            self.delegate = (segue.destinationViewController as? Screen2ViewController)!
        }
    }

}

