//
//  MyNotificationProtocol.swift
//  TestProtocols2Swift
//
//  Created by Robert Seitsinger on 10/1/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import Foundation

protocol MyNotificationProtocol
{
    func notified(message:String)
}
