//
//  Screen1ViewController.swift
//  TestProtocols2Swift
//
//  Created by Robert Seitsinger on 10/1/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class Screen1ViewController: UIViewController, MyNotificationProtocol {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func notified(message:String) {
        // We dispatch to the main thread because it's UI stuff we want to do and
        // because we don't know what thread called us.
        dispatch_async(dispatch_get_main_queue()) {
            let alertController = UIAlertController(title: "Screen 1 Message Received", message: message, preferredStyle: UIAlertControllerStyle.Alert)
            
            let OKAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action:UIAlertAction) in
            }
            alertController.addAction(OKAction)
            
            self.presentViewController(alertController, animated: true, completion:nil)
        }
    }

}
