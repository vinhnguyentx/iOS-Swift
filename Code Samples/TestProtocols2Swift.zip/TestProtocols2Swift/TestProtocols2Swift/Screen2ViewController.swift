//
//  Screen2ViewController.swift
//  TestProtocols2Swift
//
//  Created by Robert Seitsinger on 10/1/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class Screen2ViewController: UIViewController, MyNotificationProtocol {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func notified(message:String) {
        print("Screen 2 message received. Message: \(message)")
    }

}
