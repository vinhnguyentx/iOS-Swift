//
//  ViewController.swift
//  TestFrameAndBoundsSwift
//
//  Created by Robert Seitsinger on 9/21/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.constructViews()
    }
    
    func constructViews() {

        // Define the font to use for the labels
        let labelFont:UIFont! = UIFont(name: "Courier-Bold", size:10.0)

        // Get the main window bounds. You don't typically mess with this.
        // The main window frame and bounds are usually the same.
        let mainWindowRect:CGRect = appDelegate.window!.bounds

        // Create a view that is view1Inset points within the main view.
        // That is, view1 is a child of the main view.
        // This view will contain another view.
        let view1Inset:CGFloat = 20.0
        
        let view1X:CGFloat = mainWindowRect.origin.x + view1Inset
        let view1Y:CGFloat = mainWindowRect.origin.y + view1Inset
        let view1Width:CGFloat = mainWindowRect.size.width - (view1Inset * 2)
        let view1Height:CGFloat = mainWindowRect.size.height - (view1Inset * 2)
        
        let view1:UIView = UIView(frame: CGRect(x:view1X, y:view1Y, width:view1Width, height:view1Height))
        
        view1.backgroundColor = UIColor(red: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
        
        self.view.addSubview(view1)
        
        // Create a view that is view2Inset inside the first view. And is a child view of view1.
        let view2Inset:CGFloat = 50.0
        
        let view1Rect:CGRect = view1.bounds

        let view2X:CGFloat = view1Rect.origin.x + view2Inset
        let view2Y:CGFloat = view1Rect.origin.y + view2Inset
        let view2Width:CGFloat = view1Rect.size.width - (view2Inset * 2)
        let view2Height:CGFloat = view1Rect.size.height - (view2Inset * 2)
        
        let view2:UIView = UIView(frame: CGRect(x:view2X, y:view2Y, width:view2Width, height:view2Height))
        
        ////////////////////////////////////////////////////////////////////////////////////
        // Do one of these tweaks at a time.
        
        ////////////////////////////////////////////////////////////////////////////////////
        // Tweak the view bounds #1. Shift it left (x)/up (y) 20 points.
        // This causes the UI elements within the red rectangle to move down and right,
        // because the origin of the labels are still at (0, 0).
//        var view2Bounds:CGRect = view2.bounds
//        view2Bounds.origin.x -= 20.0
//        view2Bounds.origin.y -= 20.0
//        view2.bounds = view2Bounds
        ////////////////////////////////////////////////////////////////////////////////////
        
        ////////////////////////////////////////////////////////////////////////////////////
        // Tweak the view bounds #2. Shift it right (x)/down (y) 15 points.
        // This causes the UI elements within the red rectangle to move up and left,
        // because the origin of the labels are still at (0, 0).
//        var view2Bounds:CGRect = view2.bounds
//        view2Bounds.origin.x += 15.0
//        view2Bounds.origin.y += 15.0
//        view2.bounds = view2Bounds
//        
//        view2.clipsToBounds = true
        ////////////////////////////////////////////////////////////////////////////////////

        view2.backgroundColor = UIColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
        
        view1.addSubview(view2)

        // Create labels for view 1
        let label1X:CGFloat = 20.0
        let label1Y:CGFloat = 7.0
        let label1Width:CGFloat = view1Rect.size.width - (10.0 * 2)
        let label1Height:CGFloat = 30.0

        let label2X:CGFloat = 20.0
        let label2Y:CGFloat = label1Y + 15.0
        let label2Width:CGFloat = label1Width
        let label2Height:CGFloat = label1Height

        let label3X:CGFloat = 15.0
        let label3Y:CGFloat = view1Height - 40.0
        let label3Width:CGFloat = label1Width
        let label3Height:CGFloat = label1Height
        
        let label1:UILabel = UILabel(frame: CGRect(x:label1X, y:label1Y, width:label1Width, height:label1Height))
        let label2:UILabel = UILabel(frame: CGRect(x:label2X, y:label2Y, width:label2Width, height:label2Height))
        let label3:UILabel = UILabel(frame: CGRect(x:label3X, y:label3Y, width:label3Width, height:label3Height))
        
        label1.text = "Frame: x:\(view1.frame.origin.x), y:\(view1.frame.origin.y), w:\(view1.frame.size.width), h:\(view1.frame.size.height)"
        label1.font = labelFont
        label2.text = "Bounds: x:\(view1.bounds.origin.x), y:\(view1.bounds.origin.y), w:\(view1.bounds.size.width), h:\(view1.bounds.size.height)"
        label2.font = labelFont
        label3.text = "Window: x:\(mainWindowRect.origin.x), y:\(mainWindowRect.origin.y), w:\(mainWindowRect.size.width), h:\(mainWindowRect.size.height)"
        label3.font = labelFont

        view1.addSubview(label1)
        view1.addSubview(label2)
        view1.addSubview(label3)

        let view2Rect:CGRect = view2.bounds
        
        // Create labels for view 2
        let label4X:CGFloat = 0.0
        let label4Y:CGFloat = 0.0
        let label4Width:CGFloat = view2Rect.size.width - (10.0 * 2)
        let label4Height:CGFloat = 50.0
        
        let label5X:CGFloat = 0.0
        let label5Y:CGFloat = label4Height + 10.0
        let label5Width:CGFloat = label4Width
        let label5Height:CGFloat = label4Height
        
        let label4:UILabel = UILabel(frame: CGRect(x:label4X, y:label4Y, width:label4Width, height:label4Height))
        let label5:UILabel = UILabel(frame: CGRect(x:label5X, y:label5Y, width:label5Width, height:label5Height))
        
        label4.text = "Frame:\n x:\(view2.frame.origin.x)\n y:\(view2.frame.origin.y)\n w:\(view2.frame.size.width)\n h:\(view2.frame.size.height)"
        label4.font = labelFont
        label4.numberOfLines = 0
        
        label5.text = "Bounds:\n x:\(view2.bounds.origin.x)\n y:\(view2.bounds.origin.y)\n w:\(view2.bounds.size.width)\n h:\(view2.bounds.size.height)"
        label5.font = labelFont
        label5.numberOfLines = 0
        
        view2.addSubview(label4)
        view2.addSubview(label5)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

