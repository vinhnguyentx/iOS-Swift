//
//  ViewController.swift
//  TestSegmentedControlSwift
//
//  Created by Robert Seitsinger on 9/23/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var currentTwoOption = 0
    var currentFourOption = 0
    
    @IBOutlet weak var segControlTwoOptions: UISegmentedControl!
    @IBOutlet weak var segControlFourOptions: UISegmentedControl!
    
    @IBOutlet weak var lblSegment1Message: UILabel!
    @IBOutlet weak var lblSegment2Message: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // To start.
        self.lblSegment1Message.text = "First selected"
        self.lblSegment2Message.text = "North selected"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // Action handler method for when the user touches one of the buttons
    // in the two-button segmented control.
    @IBAction func segControlTwoOptionsAction(sender: AnyObject) {
        self.currentTwoOption = self.segControlTwoOptions.selectedSegmentIndex
        self.setTwoOptionsLabelText()
    }
    
    // Action handler method for when the user touches one of the buttons
    // in the four-button segmented control.
    @IBAction func segControlFourOptionsAction(sender: AnyObject) {
        self.currentFourOption = self.segControlFourOptions.selectedSegmentIndex
        self.setFourOptionsLabelText()
    }

    // Set the label text for the label that is under the two-button segmented control.
    func setTwoOptionsLabelText() {
        switch self.segControlTwoOptions.selectedSegmentIndex
        {
        case 0:
            self.lblSegment1Message.text = "First selected"
        case 1:
            self.lblSegment1Message.text = "Second selected"
        default:
            break
        }
    }
    
    // Set the label text for the label that is under the four-button segmented control.
    func setFourOptionsLabelText() {
        switch self.segControlFourOptions.selectedSegmentIndex
        {
        case 0:
            self.lblSegment2Message.text = "North selected"
        case 1:
            self.lblSegment2Message.text = "South selected"
        case 2:
            self.lblSegment2Message.text = "East selected"
        case 3:
            self.lblSegment2Message.text = "West selected"
        default:
            break
        }
    }
    
    // Action handler for the Next button under the two-button segmented control.
    @IBAction func btnNextTwoOptions(sender: AnyObject) {
        // Determine the next index, to cycle through the available buttons.
        self.currentTwoOption = (self.segControlTwoOptions.selectedSegmentIndex + 1) % 2
        self.segControlTwoOptions.selectedSegmentIndex = self.currentTwoOption
        self.setTwoOptionsLabelText()
    }
    
    // Action handler for the Next button under the four-button segmented control.
    @IBAction func btnNextFourOptions(sender: AnyObject) {
        // Determine the next index, to cycle through the available buttons.
        self.currentFourOption = (self.segControlFourOptions.selectedSegmentIndex + 1) % 4
        self.segControlFourOptions.selectedSegmentIndex = self.currentFourOption
        self.setFourOptionsLabelText()
    }
    
}

