//
//  DetailViewController.swift
//  TestTableViewApp
//
//  Created by Robert Seitsinger on 9/10/15.
//  Copyright (c) 2015 cs378. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet var lblName:UILabel? = nil
    @IBOutlet var lblAge:UILabel? = nil
    
    var person:Person?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.title = "Person Details"
        
        self.lblName!.text = "\(person!.firstName) \(person!.lastName)"
        self.lblAge!.text = "\(person!.age)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
