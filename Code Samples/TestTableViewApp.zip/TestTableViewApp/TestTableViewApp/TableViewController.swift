//
//  TableViewController.swift
//  TestTableViewApp
//
//  Created by Robert Seitsinger on 9/10/15.
//  Copyright (c) 2015 cs378. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    var people:[Person] = [Person]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Person List"
        
        self.people.append(Person(firstName: "Joe", lastName: "Johnson", age: 35))
        self.people.append(Person(firstName: "Sam", lastName: "Smith", age: 27))
        self.people.append(Person(firstName: "Sue", lastName: "Jefferson", age: 52))
        self.people.append(Person(firstName: "Zoey", lastName: "Zimmerman", age: 17))
        self.people.append(Person(firstName: "Alan", lastName: "Albright", age: 83))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return self.people.count;
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cellid", forIndexPath: indexPath)

        let person = self.people[indexPath.row]
        
        cell.textLabel!.text = person.firstName
        cell.detailTextLabel!.text = person.lastName
        
        return cell
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
        
        let indexPath = self.tableView.indexPathForSelectedRow
        
        let detailViewController = segue.destinationViewController as! DetailViewController
        
        detailViewController.person = self.people[indexPath!.row]
    }

}
