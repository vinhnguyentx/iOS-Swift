//
//  ViewController.swift
//  TestAlertController
//
//  Created by Robert Seitsinger on 9/15/15.
//  Copyright (c) 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var alertController:UIAlertController? = nil
    var loginTextField: UITextField? = nil
    var passwordTextField: UITextField? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSimpleAlert(sender: AnyObject) {
        self.alertController = UIAlertController(title: "Alert Controller", message: "Simple Alert Controller", preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action:UIAlertAction) in
            print("Ok Button Pressed 1");
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action:UIAlertAction) in
            print("Cancel Button Pressed 1");
        }

        self.alertController!.addAction(okAction)
        self.alertController!.addAction(cancelAction)
        
        self.presentViewController(self.alertController!, animated: true, completion:nil)
    }

    @IBAction func btnAlertWithTextField(sender: AnyObject) {
        self.alertController = UIAlertController(title: "Alert Controller", message: "Alert Controller With a Text Field", preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Ok Button Pressed 2")
            print("You entered \(self.loginTextField!.text!)")
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            print("Cancel Button Pressed 2")
        }
        
        self.alertController!.addAction(okAction)
        self.alertController!.addAction(cancelAction)
        
        self.alertController!.addTextFieldWithConfigurationHandler { (textField) -> Void in
            // Enter the textfield customization code here.
            self.loginTextField = textField
            self.loginTextField?.placeholder = "Enter your login ID"
        }
        
        presentViewController(self.alertController!, animated: true, completion: nil)
    }
    
    @IBAction func btnAlertWithLoginForm(sender: AnyObject) {
        self.alertController = UIAlertController(title: "Alert Controller", message: "Alert Controller With a Login Form", preferredStyle: UIAlertControllerStyle.Alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Ok Button Pressed")
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            print("Cancel Button Pressed")
        }
        
        self.alertController!.addAction(okAction)
        self.alertController!.addAction(cancelAction)
        
        self.alertController!.addTextFieldWithConfigurationHandler { (textField) -> Void in
            // Enter the textfield customization code here.
            self.loginTextField = textField
            self.loginTextField?.placeholder = "User ID"
        }
        self.alertController!.addTextFieldWithConfigurationHandler { (textField) -> Void in
            // Enter the textfield customization code here.
            self.passwordTextField = textField
            self.passwordTextField?.placeholder = "Password"
            self.passwordTextField?.secureTextEntry = true
        }
        
        presentViewController(self.alertController!, animated: true, completion: nil)
    }
    
    @IBAction func btnAlertWithMultipleButtons(sender: AnyObject) {
        self.alertController = UIAlertController(title: "Alert Controller", message: "Alert Controller with multiple buttons", preferredStyle: UIAlertControllerStyle.Alert)
        
        let buttonOne = UIAlertAction(title: "One", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Button One Pressed")
        })
        let buttonTwo = UIAlertAction(title: "Two", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Button Two Pressed")
        })
        let buttonThree = UIAlertAction(title: "Three", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Button Three Pressed")
        })
        let buttonFour = UIAlertAction(title: "Four", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Button Four Pressed")
        })
        let buttonCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
            print("Cancel Button Pressed")
        }
        
        self.alertController!.addAction(buttonOne)
        self.alertController!.addAction(buttonTwo)
        self.alertController!.addAction(buttonThree)
        self.alertController!.addAction(buttonFour)
        self.alertController!.addAction(buttonCancel)
        
        presentViewController(self.alertController!, animated: true, completion: nil)
    }
    
    @IBAction func btnActionSheet(sender: AnyObject) {
        self.alertController = UIAlertController(title: "Action Sheet", message: "Action Sheet With 3 Buttons", preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: { (action) -> Void in
            print("Ok Button Pressed")
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel, handler: { (action) -> Void in
            print("Cancel Button Pressed")
        })
        let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.Destructive) { (action) -> Void in
            print("Delete Button Pressed")
        }
        
        self.alertController!.addAction(okAction)
        self.alertController!.addAction(cancelAction)
        self.alertController!.addAction(deleteAction)
        
        presentViewController(self.alertController!, animated: true, completion: nil)
    }
}

