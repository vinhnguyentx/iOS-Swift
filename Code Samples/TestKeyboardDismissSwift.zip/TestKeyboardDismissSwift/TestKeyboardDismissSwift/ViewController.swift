//
//  ViewController.swift
//  TestKeyboardDismissSwift
//
//  Created by Robert Seitsinger on 2/3/16.
//  Copyright © 2016 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var txtField:UITextField!   // create a textfield variable
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // You have to identify this object (self) as the one that will receive delegate calls
        // (think old-fashioned callbacks) from the framework code that handles UITextField
        // events. If you don't, the framework's call to textFieldShouldReturn (below) won't
        // get here, and the keyboard won't go away using this mechanism.
        self.txtField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // UITextFieldDelegate delegate method
    //
    // This method is called when the user touches the Return key on the
    // keyboard. The 'textField' passed in is a pointer to the textField
    // widget the cursor was in at the time they touched the Return key on
    // the keyboard.
    //
    // From the Apple documentation: Asks the delegate if the text field
    // should process the pressing of the return button.
    //
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        // A responder is an object that can respond to events and handle them.
        //
        // Resigning first responder here means this text field will no longer be the first
        // UI element to receive an event from this apps UI - you can think of it as giving
        // up input 'focus'.
        self.txtField.resignFirstResponder()
        
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    // This causes the keyboard to go away also - but handles all situations when
    // the user touches anywhere outside the keyboard.
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
}

