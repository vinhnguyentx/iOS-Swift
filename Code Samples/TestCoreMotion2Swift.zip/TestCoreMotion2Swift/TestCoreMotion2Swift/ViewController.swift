//
//  ViewController.swift
//  TestCoreMotion2Swift
//
//  Created by Robert Seitsinger on 11/9/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit
import CoreMotion
//import QuartzCore

class ViewController: UIViewController {

    // Create a shared CMMotionManager object - provides access to all sensor APIs.
    let motionManager = CMMotionManager()
    
    // This object allows us to sync our motion sensor data pull to the screen refresh rate.
    var displayLink = CADisplayLink()
    
    let kDeviceMotionUpdateFrequency = (1.0 / 3.0)
    
    @IBOutlet weak var lblAccX: UILabel!
    @IBOutlet weak var lbAccY: UILabel!
    @IBOutlet weak var lblAccZ: UILabel!
    
    @IBOutlet weak var lblGravX: UILabel!
    @IBOutlet weak var lblGravY: UILabel!
    @IBOutlet weak var lblGravZ: UILabel!
    
    @IBOutlet weak var lblRotX: UILabel!
    @IBOutlet weak var lblRotY: UILabel!
    @IBOutlet weak var lblRotZ: UILabel!
    
    @IBOutlet weak var lblAttPitch: UILabel!
    @IBOutlet weak var lblAttRoll: UILabel!
    @IBOutlet weak var lblAttYaw: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Define how frequently we want to receive updates. The updates are received in the code blocks below.
        self.motionManager.accelerometerUpdateInterval = kDeviceMotionUpdateFrequency
        self.motionManager.gyroUpdateInterval = kDeviceMotionUpdateFrequency
        self.motionManager.deviceMotionUpdateInterval = kDeviceMotionUpdateFrequency

        // Setup push of motion data changes - using the 'push' methodology.
        
        // '#if true' - enables usage of the device motion object.
        // '#if false' - enables usage of the accelerometer and gyro objects.
        
#if true // use deviceMotion object
        let refFrame:CMAttitudeReferenceFrame = CMAttitudeReferenceFrame.XArbitraryCorrectedZVertical
        let availableRefFrames:CMAttitudeReferenceFrame = CMMotionManager.availableAttitudeReferenceFrames()
        
        let isSelectedRefFrameAvailable = Bool(availableRefFrames.rawValue & refFrame.rawValue)

        if isSelectedRefFrameAvailable {
            self.motionManager.startDeviceMotionUpdatesUsingReferenceFrame(refFrame)
        } else {
            self.motionManager.startDeviceMotionUpdates()
        }
#else // use the accelerometer and gyro separately
        self.motionManager.startAccelerometerUpdates()
        self.motionManager.startGyroUpdates()
#endif
        
        // Define a method to execute every screen refresh cycle.
        self.displayLink = CADisplayLink(target: self, selector: Selector("updateMotionData"))
        self.displayLink.frameInterval = 1
        self.displayLink.addToRunLoop(NSRunLoop.currentRunLoop(), forMode: NSRunLoopCommonModes)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Lock to portrait orientation
    override func shouldAutorotate() -> Bool {
        return false
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return [UIInterfaceOrientationMask.Portrait]
    }

    // Use the 'pull' method to display updated motion sensor data.
    // With this methodology you typically miss some data updates, but as long as
    // the frequency this method is called is often enough for your app's purposes, then
    // you're ok.
    func updateMotionData() {

        let mm:CMMotionManager = self.motionManager
        
        // Don't try to get motion data until the hardware has settled down.
        if mm.deviceMotionAvailable && mm.deviceMotionActive && mm.deviceMotion != nil {
            let acceleration:CMAcceleration = mm.deviceMotion!.userAcceleration
            self.lblAccX.text = String(format:"%.3f", acceleration.x)
            self.lbAccY.text = String(format:"%.3f", acceleration.y)
            self.lblAccZ.text = String(format:"%.3f", acceleration.z)

            let gravity:CMAcceleration = mm.deviceMotion!.gravity
            self.lblGravX.text = String(format:"%.3f", gravity.x)
            self.lblGravY.text = String(format:"%.3f", gravity.y)
            self.lblGravZ.text = String(format:"%.3f", gravity.z)

            let rotation:CMRotationRate = mm.deviceMotion!.rotationRate
            self.lblRotX.text = String(format:"%.3f", rotation.x)
            self.lblRotY.text = String(format:"%.3f", rotation.y)
            self.lblRotZ.text = String(format:"%.3f", rotation.z)

            let attitude:CMAttitude = mm.deviceMotion!.attitude
            self.lblAttPitch.text = String(format:"%.3f", attitude.pitch)
            self.lblAttRoll.text = String(format:"%.3f", attitude.roll)
            self.lblAttYaw.text = String(format:"%.3f", attitude.yaw)
        }
        
        // Don't try to get accelerator data until the hardware has settled down.
        if mm.accelerometerAvailable && mm.accelerometerActive && mm.accelerometerData != nil {
            let acceleration:CMAcceleration = mm.accelerometerData!.acceleration
            self.lblAccX.text = String(format:"%.3f", acceleration.x)
            self.lbAccY.text = String(format:"%.3f", acceleration.y)
            self.lblAccZ.text = String(format:"%.3f", acceleration.z)
        }
        
        // Don't try to get gyro data until the hardware has settled down.
        if mm.gyroAvailable && mm.gyroActive && mm.gyroData != nil {
            let rotation:CMRotationRate = mm.gyroData!.rotationRate
            self.lblRotX.text = String(format:"%.3f", rotation.x)
            self.lblRotY.text = String(format:"%.3f", rotation.y)
            self.lblRotZ.text = String(format:"%.3f", rotation.z)
        }
        
        // Don't try to get magneto data until the hardware has settled down.
        if mm.magnetometerAvailable && mm.magnetometerActive && mm.magnetometerData != nil {
            let magField:CMMagneticField = mm.magnetometerData!.magneticField // magnetic field in microteslas (x,y,z)
        }
    }
}

