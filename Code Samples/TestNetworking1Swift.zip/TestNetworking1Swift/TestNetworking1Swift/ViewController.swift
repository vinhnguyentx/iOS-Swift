//
//  ViewController.swift
//  TestNetworking1Swift
//
//  Created by Robert Seitsinger on 10/26/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var weather:NSArray? = nil
    var alertController:UIAlertController? = nil
    
    @IBOutlet weak var txtFieldCity: UITextField!
    @IBOutlet weak var txtFieldDate: UITextField!
    @IBOutlet weak var txtFieldNumDays: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        self.tableView.separatorStyle = .SingleLine
        self.tableView.separatorColor = UIColor.blackColor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnGetWeatherAction(sender: AnyObject) {
        let urlPathBase = "http://api.worldweatheronline.com/free/v2/weather.ashx?key=fc371a731202b57b2edc7a687df17&format=json"
        let urlCityPrefix = "&q="
        let urlDatePrefix = "&date="
        let urlNumDaysPrefix = "&num_of_days="

        var urlPath = urlPathBase
        urlPath = urlPath + urlCityPrefix + self.txtFieldCity.text!
        urlPath = urlPath + urlDatePrefix + self.txtFieldDate.text!
        urlPath = urlPath + urlNumDaysPrefix + self.txtFieldNumDays.text!
        
        let url:NSURL? = NSURL(string: urlPath)

        if (url == nil) {
            self.displayMessage("url is nil. Can't initiate request.")
            return
        }

        let session = NSURLSession.sharedSession()

        let task = session.dataTaskWithURL(url!) { (data, response, error) -> Void in
            print("Data get returned")
            if error != nil {
                self.displayMessage("Error returned from request: " + error!.localizedDescription)
            } else {
                //print(response)
                do {
                    let jsonResult = try NSJSONSerialization.JSONObjectWithData(data!, options: NSJSONReadingOptions.MutableContainers) as? NSDictionary
                    if jsonResult != nil {
                        if let results: NSDictionary = jsonResult!["data"] as? NSDictionary {
                            self.weather = results["weather"] as? NSArray
                            if self.weather != nil {
                                dispatch_async(dispatch_get_main_queue()) {
                                    self.tableView.reloadData()
                                }
                            } else {
                                self.displayMessage("'weather' element not found in returned payload")
                            }
                        }
                    }
                } catch {
                    // do something
                    self.displayMessage("Error parsing the payload returned")
                }
            }
        }
        task.resume() // start the request
    }

    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.weather == nil {
            return 0
        } else {
            // We're adding 1 because we have a column title row.
            return self.weather!.count + 1
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("cellId", forIndexPath: indexPath) as! DayTableViewCell
        
        // Configure the cell...
        let index:Int = indexPath.row
        
        if (index == 0) {
            // The first row of the table are column titles
            cell.lblDate!.text = "Date"
            cell.lblMinTemp!.text = "Low"
            cell.lblMaxTemp!.text = "Hi"
        } else {
            // Row 1 and beyond are data rows
            let day:NSDictionary = self.weather![index - 1] as! NSDictionary

            let date = day["date"] as! String
            let minTemp = day["mintempF"] as! String
            let maxTemp = day["maxtempF"] as! String

            cell.lblDate!.text = date
            cell.lblMinTemp!.text = minTemp
            cell.lblMaxTemp!.text = maxTemp
        }
        
        return cell
    }

    func displayMessage(message: String) {
        dispatch_async(dispatch_get_main_queue()) {
            self.alertController =
                UIAlertController(title: "Alert Controller", message: message, preferredStyle: UIAlertControllerStyle.Alert)
            
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default) { (action:UIAlertAction) in
            }
            
            self.alertController!.addAction(okAction)
            
            self.presentViewController(self.alertController!, animated: true, completion:nil)
        }
    }
}

