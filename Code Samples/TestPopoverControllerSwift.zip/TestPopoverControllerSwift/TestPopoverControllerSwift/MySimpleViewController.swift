//
//  MySimpleViewController.swift
//  TestPopoverControllerSwift
//
//  Created by Robert Seitsinger on 10/21/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class MySimpleViewController: UIViewController {

    convenience init(title:String, preferredContentSize:CGSize) {
        self.init()
        
        // Set some view controller attributes
        self.preferredContentSize = preferredContentSize
        self.title = title
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.modalPresentationStyle = UIModalPresentationStyle.Popover
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
