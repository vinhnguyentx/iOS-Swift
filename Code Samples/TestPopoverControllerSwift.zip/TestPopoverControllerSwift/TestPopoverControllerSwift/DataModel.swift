//
//  DataModel.swift
//  TestPopoverControllerSwift
//
//  Created by Robert Seitsinger on 9/22/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class DataModel {

    private var list:[FilterItem] = [FilterItem]()
    
    init() {
        // Create the list of filters
        list.append(FilterItem(title:"Urgent", color:UIColor.redColor()))
        list.append(FilterItem(title:"Ok", color:UIColor.greenColor()))
        list.append(FilterItem(title:"Important", color:UIColor.blueColor()))
        list.append(FilterItem(title:"Concerned", color:UIColor.purpleColor()))
        list.append(FilterItem(title:"Concerned2", color:UIColor.purpleColor()))
        list.append(FilterItem(title:"Concerned3", color:UIColor.purpleColor()))
        list.append(FilterItem(title:"Concerned4", color:UIColor.purpleColor()))
    }
    
    func count() -> Int {
        return list.count
    }
    
    func getFilterItem(index index:Int) -> FilterItem {
        if index < list.count {
            return list[index]
        } else {
            return FilterItem(title: "<bad title>", color:UIColor.blackColor())
        }
    }
}