//
//  FilterItem.swift
//  TestPopoverControllerSwift
//
//  Created by Robert Seitsinger on 9/22/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class FilterItem {
    private var _title:String = ""
    private var _color:UIColor = UIColor.blackColor()
    
    var title:String {
        get {
            return _title
        }
        set (newValue) {
            _title = newValue
        }
    }
    var color:UIColor {
        get {
            return _color
        }
        set(newVal) {
            _color = newVal
        }
    }
    
    init(title:String, color:UIColor) {
        self.title = title
        self.color = color
    }
    
    convenience init() {
        self.init(title:"<no title>", color:UIColor.blackColor())
    }
    
    func description() -> String {
        return "Title: \(self.title), Color: \(self.color)"
    }
}

