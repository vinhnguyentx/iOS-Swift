//
//  MyPopoverViewController2.swift
//  TestPopoverControllerSwift
//
//  Created by Robert Seitsinger on 10/21/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class MyPopoverViewController2: UIViewController, UIPopoverPresentationControllerDelegate {

    var simpleViewController:MySimpleViewController? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func presentPopover(sourceController sourceController:UIViewController, sourceView:UIView, sourceRect:CGRect) {
        
        // Create the view controller we want to display as the popup.
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        self.simpleViewController = storyboard.instantiateViewControllerWithIdentifier("MySimpleVCStoryboard") as? MySimpleViewController
        self.simpleViewController!.title = "Labels"
        self.simpleViewController!.preferredContentSize = CGSize(width: 300, height: 180)
        
        // Cause the views to be created in this view controller. Gets them added to the view hierarchy.
        self.simpleViewController?.view
        self.simpleViewController?.view.layoutIfNeeded()
        
        // Set attributes for the popover controller.
        // Notice we're get an existing object from the view controller we want to popup!
        let popoverMenuViewController = self.simpleViewController!.popoverPresentationController
        popoverMenuViewController?.permittedArrowDirections = .Any
        popoverMenuViewController?.delegate = self
        popoverMenuViewController?.sourceView = sourceView
        popoverMenuViewController?.sourceRect = sourceRect
        
        // Show the popup.
        // Notice we are presenting form a view controller passed in. We need to present from a view controller
        // that has views that are already in the view hierarchy.
        sourceController.presentViewController(self.simpleViewController!, animated: true, completion: nil)
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        // Indicate we want the same presentation behavior on both iPhone and iPad.
        return UIModalPresentationStyle.None
    }

}
