//
//  ViewController.swift
//  TestPopoverControllerSwift
//
//  Created by Robert Seitsinger on 9/22/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnShowPopover: UIButton!
    @IBOutlet weak var btnShowPopover2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnAction(sender: AnyObject) {
        
        // Instantiate our popover class and call it's present method.
        
        let popOverController = MyPopoverViewController()
        
        popOverController.presentPopover(sourceController: self, sourceView: self.btnShowPopover, sourceRect: self.btnShowPopover.bounds)
    }

    @IBAction func btnShowSimpleVCAction(sender: AnyObject) {
        // Instantiate our popover class and call it's present method.
        
        let popOverController = MyPopoverViewController2()
        
        popOverController.presentPopover(sourceController: self, sourceView: self.btnShowPopover2, sourceRect: self.btnShowPopover2.bounds)
    }
    
}

