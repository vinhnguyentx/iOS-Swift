//
//  FadeViewController.swift
//  TestAnimation1Swift
//
//  Created by Robert Seitsinger on 10/7/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class FadeViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lblHeyThere: UILabel!
    @IBOutlet weak var lblHeyThereAgain: UILabel!
    @IBOutlet weak var txtFieldDuration: UITextField!
    @IBOutlet weak var txtFieldDelay: UITextField!
    @IBOutlet weak var switchRepeat: UISwitch!
    @IBOutlet weak var switchReverse: UISwitch!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var txtFieldTimes: UITextField!
    
    let defaultDuration = 3.0
    let defaultDelay = 0.5
    let defaultTimes = 10
    var stopAnimation = false
    var animateCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Fade Demo"
        
        // Set the back button text. Don't use the default.
        let barButton:UIBarButtonItem = UIBarButtonItem()
        barButton.title = "Back"
        self.navigationController!.navigationBar.topItem!.backBarButtonItem = barButton;

        self.lblHeyThere.alpha = 1.0
        self.lblHeyThereAgain.alpha = 1.0
        
        // Set the delegate for the text fields, so you can hide the keyboard
        self.txtFieldDuration?.delegate = self
        self.txtFieldDelay?.delegate = self
        self.txtFieldTimes?.delegate = self
        
        self.lblHeyThere.text = "<label to fade>"
        self.lblHeyThereAgain.text = "<label to fade>"
        self.txtFieldDuration.text = String(defaultDuration)
        self.txtFieldDelay.text = String(defaultDelay)
        
        self.lblMessage.text = ""
        
        // Set the repeat count
        self.txtFieldTimes.text = String(defaultTimes)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnFadeIn1Action(sender: AnyObject) {
        // Define starting point for the view we're going to animate.
        self.lblHeyThere.alpha = 0.0;
        self.lblHeyThere.text = "Hey There";
        
        self.lblMessage.text = "";
        
        // Fade the label into view
        
        UIView.animateWithDuration(defaultDuration, delay: defaultDelay, options: .CurveLinear,
            animations: {
                self.lblHeyThere.alpha = 1.0
            },
            completion: { finished in
                self.lblMessage.text = "Basic Fade In Animation Done"
            }
        )
    }
    
    @IBAction func btnFadeOut1Action(sender: AnyObject) {
        // Define starting point for the view we're going to animate.
        self.lblHeyThere.alpha = 1.0;
        self.lblHeyThere.text = "Hey There";
        
        self.lblMessage.text = "";
        
        // Fade the label out of view
        UIView.animateWithDuration(defaultDuration, delay: defaultDelay, options: .CurveLinear,
            animations: {
                self.lblHeyThere.alpha = 0.0
            },
            completion: { finished in
                self.lblMessage.text = "Basic Fade Out Animation Done"
            }
        )
    }
    
    @IBAction func btnFadeIn2Action(sender: AnyObject) {

        self.lblHeyThereAgain.text = "Hey There, again!"
        
        dispatch_async(dispatch_get_main_queue()) {
            self.lblMessage.text = ""
            self.lblHeyThereAgain.alpha = 0.0
            
            let animationCount:Int = Int(self.txtFieldTimes.text!)! - 1
            
            self.doFade( [UIViewAnimationOptions.CurveEaseIn], startAlpha: 0.0, endAlpha: 1.0, animationCount: animationCount)
        }
    }
    
    @IBAction func btnFadeOut2Action(sender: AnyObject) {
        self.lblHeyThereAgain.text = "Hey There, again!"

        dispatch_async(dispatch_get_main_queue()) {
            self.lblMessage.text = ""
            self.lblHeyThereAgain.alpha = 1.0
            
            let animationCount:Int = Int(self.txtFieldTimes.text!)! - 1
            
            self.doFade( [UIViewAnimationOptions.CurveEaseOut], startAlpha: 1.0, endAlpha: 0.0, animationCount: animationCount)
        }
    }
    
    func doFade(options:UIViewAnimationOptions, startAlpha:Float, endAlpha:Float, animationCount:Int) {
        
        print("doFade: startAlpha: \(startAlpha), endAlpha: \(endAlpha), animationCount: \(animationCount)")
        
        let strDuration = self.txtFieldDuration.text
        let strDelay = self.txtFieldDelay.text
        let duration = Double(strDuration!)!
        let delay = Double(strDelay!)!
        
        self.animateCount = animationCount
        
        let options = self.getAnimationOptions(.CurveLinear)
        
        UIView.animateWithDuration(duration, delay: delay, options: options,
            animations: {
                self.lblHeyThereAgain.alpha = CGFloat(endAlpha)
            },
            completion: { finished in
                if (self.switchRepeat.on && self.animateCount > 0) {
                    dispatch_async(dispatch_get_main_queue()) {
                        self.lblHeyThereAgain.alpha = CGFloat(startAlpha);
                        self.doFade(options, startAlpha: startAlpha, endAlpha: endAlpha, animationCount: --self.animateCount)
                    }
                } else {
                    self.lblMessage.text = "Enhanced Animation Done"
                }
            }
        )
    }
    
    func getAnimationOptions(startingOptions:UIViewAnimationOptions) -> UIViewAnimationOptions {
        var options = startingOptions
        
// Manual count used to limit repeat count
//        if (self.switchRepeat.on) {
//            // Repeat the animation indefinitely
//            options = [options, UIViewAnimationOptions.Repeat]
//        }
        
        if (self.switchReverse.on) {
            // Run the animation backwards and forwards
            options = [options, UIViewAnimationOptions.Autoreverse]
        }
        
        return options;
    }
    
    @IBAction func btnStopAction(sender: AnyObject) {
        self.animateCount = 0
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

}
