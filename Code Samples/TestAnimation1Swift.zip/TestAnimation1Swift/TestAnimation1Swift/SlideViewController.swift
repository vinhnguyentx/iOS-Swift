//
//  SlideViewController.swift
//  TestAnimation1Swift
//
//  Created by Robert Seitsinger on 10/7/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class SlideViewController: UIViewController {

    var yCenterPosition:CGFloat = 0.0
    
    @IBOutlet weak var lblHey: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Slide Demo"
        
        // Set the back button text. Don't use the default.
        let barButton:UIBarButtonItem = UIBarButtonItem()
        barButton.title = "Back"
        self.navigationController!.navigationBar.topItem!.backBarButtonItem = barButton;
        
        // Capture the starting Y position of the label we'll be moving around.
        yCenterPosition = lblHey.center.y
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnSlideInFromRightAction(sender: AnyObject) {
        // Make sure the label is in the middle of the visible area - as a starting point.
        self.lblHey.center.x += self.view.bounds.width
        self.lblHey.center.y = yCenterPosition
        
        UIView.animateWithDuration(3.0, delay: 0.0, options: [], animations: {
            self.lblHey.center.x = self.view.center.x
            }, completion: nil)
    }
    
    @IBAction func btnSlideInFromLeftAction(sender: AnyObject) {
        // Make sure the label is in the middle of the visible area - as a starting point.
        self.lblHey.center.x -= self.view.bounds.width
        self.lblHey.center.y = yCenterPosition
        
        UIView.animateWithDuration(3.0, delay: 0.0, options: [], animations: {
            self.lblHey.center.x = self.view.center.x
            }, completion: nil)
    }
    
    @IBAction func btnSlideOutToRightAction(sender: AnyObject) {
        // Make sure the label is in the middle of the visible area - as a starting point.
        self.lblHey.center.x = self.view.center.x
        self.lblHey.center.y = yCenterPosition
        
        UIView.animateWithDuration(3.0, delay: 0.0, options: [], animations: {
            self.lblHey.center.x += self.view.bounds.width
            }, completion: nil)
    }
    
    @IBAction func btnSlideOutToLeftAction(sender: AnyObject) {
        // Make sure the label is in the middle of the visible area - as a starting point.
        self.lblHey.center.x = view.center.x
        self.lblHey.center.y = yCenterPosition
        
        UIView.animateWithDuration(3.0, delay: 0.0, options: [], animations: {
            self.lblHey.center.x -= self.view.bounds.width
            }, completion: nil)
    }

    @IBAction func brnSlideDownAction(sender: AnyObject) {
        // Make sure the label is in the middle of the visible area - as a starting point.
        self.lblHey.center.x = view.center.x
        self.lblHey.center.y = yCenterPosition
        
        UIView.animateWithDuration(3.0, delay: 0.0, options: [], animations: {
            self.lblHey.center.y += self.view.bounds.height
            }, completion: nil)
    }
}
