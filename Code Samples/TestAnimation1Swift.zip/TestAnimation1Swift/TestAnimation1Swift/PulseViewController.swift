//
//  PulseViewController.swift
//  TestAnimation1Swift
//
//  Created by Robert Seitsinger on 10/8/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class PulseViewController: UIViewController {

    private var stopPulsing = false
    private var originalFrame:CGRect = CGRect()
    private var originalCenter:CGPoint = CGPoint()

    @IBOutlet weak var lblHey: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Pulse Demo"
        
        // Set the back button text. Don't use the default.
        let barButton:UIBarButtonItem = UIBarButtonItem()
        barButton.title = "Back"
        self.navigationController!.navigationBar.topItem!.backBarButtonItem = barButton;
        
        // Remember the original frame for the label
        originalFrame = self.lblHey.frame
        originalCenter = self.lblHey.center
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnPulseAction(sender: AnyObject) {
        self.stopPulsing = false
        
        // Reset frame to the original
        self.lblHey.frame = originalFrame
        
        self.pulseMe()
    }

    func pulseMe() {
        
        // Calculate the new frame
        let adjust:CGFloat = 20.0
        let originAdjust:CGFloat = adjust / 2
        let sizeAdjust:CGFloat = adjust * 2
        
        let newFrame:CGRect = CGRect(x: originalFrame.origin.x - originAdjust, y: originalFrame.origin.y - originAdjust, width: originalFrame.size.width + sizeAdjust, height: originalFrame.size.height + sizeAdjust)
        
        UIView.animateWithDuration(0.25, delay: 0.0, options: [.CurveLinear, .Autoreverse],
            animations: {
                self.lblHey.frame = newFrame
            },
            completion: { finished in
                if (finished && !self.stopPulsing) {
                    self.pulseMe()
                }
            }
        )
    }
    
    @IBAction func btnStopPulseAction(sender: AnyObject) {
        self.stopPulsing = true
    }
}

