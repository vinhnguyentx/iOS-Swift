//
//  SpinViewController.swift
//  TestAnimation1Swift
//
//  Created by Robert Seitsinger on 10/7/15.
//  Copyright © 2015 cs378. All rights reserved.
//

import UIKit

class SpinViewController: UIViewController, UITextFieldDelegate {

    private var stopSpinning = false
    private var duration:Double = 3.0
    
    @IBOutlet weak var lblHey: UILabel!
    @IBOutlet weak var txtFieldDuration: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Spin Demo"

        // Set the back button text. Don't use the default.
        let barButton:UIBarButtonItem = UIBarButtonItem()
        barButton.title = "Back"
        self.navigationController!.navigationBar.topItem!.backBarButtonItem = barButton;
        
        self.txtFieldDuration.text = String(duration)
        
        self.txtFieldDuration.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSpinMeAction(sender: AnyObject) {

        self.stopSpinning = false
        
        self.duration = Double(self.txtFieldDuration.text!)!
        
        // Make sure the starting point for the transform is as the label was to start with.
        self.lblHey.transform = CGAffineTransformIdentity

        self.spinMe()
    }

    func spinMe() {
        
        UIView.animateWithDuration(duration, delay: 0.0, options: [.CurveLinear],
            animations: {
                self.lblHey.transform = CGAffineTransformRotate(self.lblHey.transform, CGFloat(M_PI))
            },
            completion: { finished in
                if (finished && !self.stopSpinning) {
                    self.spinMe()
                }
            }
        )
    }
    
    @IBAction func btnStopSpinningAction(sender: AnyObject) {
        self.stopSpinning = true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // Capture the current duration setting.
        self.duration = Double(self.txtFieldDuration.text!)!
        
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        // Capture the current duration setting.
        self.duration = Double(self.txtFieldDuration.text!)!
        
        self.view.endEditing(true)
    }

}
